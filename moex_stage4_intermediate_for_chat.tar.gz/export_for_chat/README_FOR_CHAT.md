# Intermediate Stage 4 MOEX tail-index results

Run ID: shares_raw_2015_main

Context:
- Market: shares
- Start date: 2015-01-01
- Windows: 504, 756, 1008
- Step: 21
- Tail side: lower
- Filter method: raw
- Bootstrap reps: 500
- Block lengths: 5, 10, 15, 21
- CI level: 0.90
- Strict probability: 0.95

Files:
- stage4_tail_alpha_estimates_partial.csv: intermediate rolling tail-index estimates already completed.
- stage4_tail_security_progress.csv: per-security progress/status table.
- 00_tail_config.json: configuration, if available.
- 01_data_audit.csv: data audit, if available.
- 02_universe_summary.csv: selected universe summary, if available.
- moex_tail_index_stage4_db_checkpoint.py: script version used for the run.

Important:
This is a partial run, not the full 142-security result.
