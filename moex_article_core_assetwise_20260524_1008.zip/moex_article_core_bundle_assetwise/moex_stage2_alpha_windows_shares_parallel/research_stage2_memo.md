# Stage 2 robustness memo

## Outputs
- `01_stage2_universes.csv`: selected universes by market and period.
- `02_stage2_rolling_metrics.csv`: rolling DQ/DR and future risk metrics.
- `04_stage2_regressions_hac.csv`: nested HAC regressions.
- `06_stage2_vif.csv`: multicollinearity diagnostics.
- `08_tail_group_tests.csv`: test of tail-index-sorted portfolio groups.
- `09_focus_summary_dq_dr.csv`: compact DQ/DR coefficient table.

## Rolling observations by market/period

| market   | period        |   window |   horizon |   tail_prob |   n |
|:---------|:--------------|---------:|----------:|------------:|----:|
| shares   | baseline_2018 |      504 |        21 |       0.025 |  76 |
| shares   | baseline_2018 |      504 |        21 |       0.05  |  76 |
| shares   | baseline_2018 |      504 |        63 |       0.025 |  74 |
| shares   | baseline_2018 |      504 |        63 |       0.05  |  74 |
| shares   | baseline_2018 |      756 |        21 |       0.025 |  64 |
| shares   | baseline_2018 |      756 |        21 |       0.05  |  64 |
| shares   | baseline_2018 |      756 |        63 |       0.025 |  62 |
| shares   | baseline_2018 |      756 |        63 |       0.05  |  62 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 |  52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  |  52 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 |  50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  |  50 |
| shares   | full_2015     |      504 |        21 |       0.025 | 112 |
| shares   | full_2015     |      504 |        21 |       0.05  | 112 |
| shares   | full_2015     |      504 |        63 |       0.025 | 110 |
| shares   | full_2015     |      504 |        63 |       0.05  | 110 |
| shares   | full_2015     |      756 |        21 |       0.025 | 100 |
| shares   | full_2015     |      756 |        21 |       0.05  | 100 |
| shares   | full_2015     |      756 |        63 |       0.025 |  98 |
| shares   | full_2015     |      756 |        63 |       0.05  |  98 |
| shares   | full_2015     |     1008 |        21 |       0.025 |  88 |
| shares   | full_2015     |     1008 |        21 |       0.05  |  88 |
| shares   | full_2015     |     1008 |        63 |       0.025 |  86 |
| shares   | full_2015     |     1008 |        63 |       0.05  |  86 |

## Significant DQ/DR coefficients at 10% level

| market   | period        |   window |   horizon |   tail_prob | dependent         | spec_name        | param               |        coef |     t_hac |   pvalue_hac |         r2 |   n_obs |
|:---------|:--------------|---------:|----------:|------------:|:------------------|:-----------------|:--------------------|------------:|----------:|-------------:|-----------:|--------:|
| shares   | baseline_2018 |      504 |        21 |       0.025 | future_var        | full             | dr_es_concentration |  -0.143866  |  -1.9081  |  0.0563787   | 0.477775   |      76 |
| shares   | baseline_2018 |      504 |        21 |       0.025 | future_rv_ann     | full             | dr_es_concentration |  -1.13953   |  -2.55227 |  0.0107022   | 0.551832   |      76 |
| shares   | baseline_2018 |      504 |        21 |       0.025 | future_mdd        | full             | dr_es_concentration |  -0.526394  |  -2.80908 |  0.00496839  | 0.341398   |      76 |
| shares   | baseline_2018 |      504 |        21 |       0.025 | future_tail_event | dq_only          | dq_es               |   0.501476  |   1.67979 |  0.0929989   | 0.0370569  |      76 |
| shares   | baseline_2018 |      504 |        21 |       0.025 | future_tail_event | dq_dr            | dq_es               |   1.07921   |   3.8924  |  9.9259e-05  | 0.144112   |      76 |
| shares   | baseline_2018 |      504 |        21 |       0.025 | future_tail_event | dq_dr            | dr_es_concentration |  -2.3921    |  -5.67661 |  1.37392e-08 | 0.144112   |      76 |
| shares   | baseline_2018 |      504 |        21 |       0.025 | future_tail_event | dq_dr_current_es | dr_es_concentration |  -2.75685   |  -2.42786 |  0.0151882   | 0.145117   |      76 |
| shares   | baseline_2018 |      504 |        21 |       0.025 | future_tail_event | full             | dr_es_concentration |  -4.31176   |  -4.05247 |  5.06804e-05 | 0.237381   |      76 |
| shares   | baseline_2018 |      504 |        21 |       0.05  | future_es         | full             | dr_es_concentration |  -0.182423  |  -1.89717 |  0.0578059   | 0.492045   |      76 |
| shares   | baseline_2018 |      504 |        21 |       0.05  | future_var        | full             | dr_es_concentration |  -0.151459  |  -2.83376 |  0.0046004   | 0.368341   |      76 |
| shares   | baseline_2018 |      504 |        21 |       0.05  | future_rv_ann     | full             | dr_es_concentration |  -1.39526   |  -2.57113 |  0.0101367   | 0.564308   |      76 |
| shares   | baseline_2018 |      504 |        21 |       0.05  | future_mdd        | full             | dr_es_concentration |  -0.606777  |  -2.60635 |  0.00915135  | 0.348044   |      76 |
| shares   | baseline_2018 |      504 |        21 |       0.05  | future_tail_event | dr_only          | dr_es_concentration |  -1.34217   |  -3.16514 |  0.00155009  | 0.0620317  |      76 |
| shares   | baseline_2018 |      504 |        21 |       0.05  | future_tail_event | dq_dr            | dq_es               |   0.641552  |   1.73491 |  0.0827573   | 0.0974324  |      76 |
| shares   | baseline_2018 |      504 |        21 |       0.05  | future_tail_event | dq_dr            | dr_es_concentration |  -1.56374   |  -3.41219 |  0.000644422 | 0.0974324  |      76 |
| shares   | baseline_2018 |      504 |        21 |       0.05  | future_tail_event | dq_dr_current_es | dq_es               |   0.970213  |   1.73508 |  0.0827258   | 0.10358    |      76 |
| shares   | baseline_2018 |      504 |        63 |       0.025 | future_es         | dr_only          | dr_es_concentration |  -0.0756853 |  -1.82412 |  0.0681338   | 0.0253201  |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.025 | future_es         | dq_dr            | dr_es_concentration |  -0.10218   |  -2.52496 |  0.0115711   | 0.0317332  |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.025 | future_var        | dq_dr_current_es | dr_es_concentration |  -0.15113   |  -2.71483 |  0.00663105  | 0.116298   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.025 | future_var        | full             | dr_es_concentration |  -0.136939  |  -3.0489  |  0.00229683  | 0.239832   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.025 | future_rv_ann     | full             | dr_es_concentration |  -0.977655  |  -2.93733 |  0.00331055  | 0.300362   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.025 | future_mdd        | dr_only          | dr_es_concentration |  -0.288297  |  -1.69915 |  0.0892907   | 0.0687496  |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.025 | future_mdd        | dq_dr_current_es | dq_es               |  -0.309085  |  -2.03111 |  0.0422434   | 0.181587   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.025 | future_mdd        | dq_dr_current_es | dr_es_concentration |  -0.976462  |  -2.94894 |  0.00318868  | 0.181587   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.025 | future_mdd        | full             | dr_es_concentration |  -0.957681  |  -4.29903 |  1.71547e-05 | 0.309826   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.025 | future_tail_event | dq_only          | dq_es               |   0.812522  |   2.33841 |  0.0193658   | 0.117544   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.025 | future_tail_event | dq_dr            | dq_es               |   1.29389   |   2.74316 |  0.00608507  | 0.202818   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.025 | future_tail_event | dq_dr            | dr_es_concentration |  -1.93004   |  -2.44448 |  0.0145063   | 0.202818   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.025 | future_tail_event | dq_dr_current_es | dr_es_concentration |  -3.42227   |  -2.11707 |  0.0342542   | 0.22341    |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.025 | future_tail_event | full             | dr_es_concentration |  -5.13639   |  -2.68094 |  0.00734158  | 0.347825   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.05  | future_var        | dq_dr_current_es | dq_es               |  -0.0381015 |  -2.07605 |  0.0378896   | 0.117159   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.05  | future_var        | dq_dr_current_es | dr_es_concentration |  -0.0963321 |  -1.81891 |  0.0689257   | 0.117159   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.05  | future_var        | full             | dr_es_concentration |  -0.13942   |  -2.65655 |  0.00789446  | 0.278673   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.05  | future_mdd        | dq_dr_current_es | dq_es               |  -0.329513  |  -2.27516 |  0.022896    | 0.122143   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.05  | future_mdd        | dq_dr_current_es | dr_es_concentration |  -0.767565  |  -1.86413 |  0.0623031   | 0.122143   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.05  | future_mdd        | full             | dr_es_concentration |  -0.887348  |  -1.95586 |  0.0504813   | 0.286148   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.05  | future_tail_event | dr_only          | dr_es_concentration |  -0.528716  |  -1.72063 |  0.085318    | 0.0375836  |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.05  | future_tail_event | dq_dr            | dr_es_concentration |  -0.733726  |  -1.8563  |  0.0634108   | 0.125935   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.05  | future_tail_event | full             | dq_es               |   3.06205   |   2.38941 |  0.0168755   | 0.269122   |      74 |
| shares   | baseline_2018 |      504 |        63 |       0.05  | future_tail_event | full             | dr_es_concentration |  -3.05951   |  -2.14041 |  0.0323213   | 0.269122   |      74 |
| shares   | baseline_2018 |      756 |        21 |       0.025 | future_mdd        | full             | dq_es               |  -0.372906  |  -1.75864 |  0.0786381   | 0.409685   |      64 |
| shares   | baseline_2018 |      756 |        21 |       0.025 | future_tail_event | dq_dr            | dq_es               |   1.29396   |   4.57768 |  4.70167e-06 | 0.136312   |      64 |
| shares   | baseline_2018 |      756 |        21 |       0.025 | future_tail_event | dq_dr            | dr_es_concentration |  -3.16226   |  -2.74642 |  0.00602494  | 0.136312   |      64 |
| shares   | baseline_2018 |      756 |        21 |       0.025 | future_tail_event | dq_dr_current_es | dq_es               |   1.80247   |   2.17459 |  0.0296609   | 0.143259   |      64 |
| shares   | baseline_2018 |      756 |        21 |       0.05  | future_es         | full             | dq_es               |  -0.539524  |  -2.33547 |  0.0195191   | 0.674716   |      64 |
| shares   | baseline_2018 |      756 |        21 |       0.05  | future_var        | full             | dq_es               |  -0.353831  |  -2.03686 |  0.0416641   | 0.410441   |      64 |
| shares   | baseline_2018 |      756 |        21 |       0.05  | future_rv_ann     | dq_only          | dq_es               |   0.215479  |   1.85198 |  0.0640289   | 0.029704   |      64 |
| shares   | baseline_2018 |      756 |        21 |       0.05  | future_rv_ann     | dq_dr            | dq_es               |   0.198409  |   1.82316 |  0.0682798   | 0.0305369  |      64 |
| shares   | baseline_2018 |      756 |        21 |       0.05  | future_rv_ann     | full             | dq_es               |  -3.41495   |  -2.81962 |  0.00480809  | 0.663451   |      64 |
| shares   | baseline_2018 |      756 |        21 |       0.05  | future_mdd        | full             | dq_es               |  -1.37985   |  -2.18967 |  0.0285481   | 0.468466   |      64 |
| shares   | baseline_2018 |      756 |        21 |       0.05  | future_tail_event | dr_only          | dr_es_concentration |  -1.28471   |  -1.7867  |  0.0739852   | 0.047419   |      64 |
| shares   | baseline_2018 |      756 |        21 |       0.05  | future_tail_event | dq_dr            | dq_es               |   0.88597   |   1.68526 |  0.0919389   | 0.0904738  |      64 |
| shares   | baseline_2018 |      756 |        21 |       0.05  | future_tail_event | dq_dr            | dr_es_concentration |  -1.86384   |  -2.34233 |  0.019164    | 0.0904738  |      64 |
| shares   | baseline_2018 |      756 |        21 |       0.05  | future_tail_event | dq_dr_current_es | dq_es               |   1.67999   |   2.01087 |  0.0443394   | 0.105336   |      64 |
| shares   | baseline_2018 |      756 |        63 |       0.025 | future_es         | dq_dr_current_es | dq_es               |   0.104442  |   1.66102 |  0.0967091   | 0.0499079  |      62 |
| shares   | baseline_2018 |      756 |        63 |       0.025 | future_mdd        | full             | dq_es               |  -0.488092  |  -1.64788 |  0.099377    | 0.139458   |      62 |
| shares   | baseline_2018 |      756 |        63 |       0.025 | future_tail_event | dq_only          | dq_es               |   1.13024   |   2.24277 |  0.0249116   | 0.200834   |      62 |
| shares   | baseline_2018 |      756 |        63 |       0.025 | future_tail_event | dq_dr            | dq_es               |   2.39726   |   5.42889 |  5.67047e-08 | 0.439412   |      62 |
| shares   | baseline_2018 |      756 |        63 |       0.025 | future_tail_event | dq_dr            | dr_es_concentration |  -4.20079   |  -4.30189 |  1.69349e-05 | 0.439412   |      62 |
| shares   | baseline_2018 |      756 |        63 |       0.025 | future_tail_event | dq_dr_current_es | dq_es               |   1.62037   |   1.73205 |  0.0832649   | 0.460815   |      62 |
| shares   | baseline_2018 |      756 |        63 |       0.025 | future_tail_event | dq_dr_current_es | dr_es_concentration |  -8.18115   |  -2.51582 |  0.0118756   | 0.460815   |      62 |
| shares   | baseline_2018 |      756 |        63 |       0.025 | future_tail_event | full             | dr_es_concentration | -11.9775    |  -1.83377 |  0.0666879   | 0.580024   |      62 |
| shares   | baseline_2018 |      756 |        63 |       0.05  | future_es         | full             | dq_es               |  -0.76354   |  -1.93771 |  0.0526591   | 0.299524   |      62 |
| shares   | baseline_2018 |      756 |        63 |       0.05  | future_var        | full             | dq_es               |  -0.246023  |  -1.70833 |  0.0875754   | 0.264914   |      62 |
| shares   | baseline_2018 |      756 |        63 |       0.05  | future_var        | full             | dr_es_concentration |   0.645543  |   1.76627 |  0.0773509   | 0.264914   |      62 |
| shares   | baseline_2018 |      756 |        63 |       0.05  | future_rv_ann     | dq_dr_current_es | dq_es               |   0.478146  |   1.7357  |  0.0826165   | 0.0463459  |      62 |
| shares   | baseline_2018 |      756 |        63 |       0.05  | future_rv_ann     | full             | dq_es               |  -4.37543   |  -2.05773 |  0.0396164   | 0.338825   |      62 |
| shares   | baseline_2018 |      756 |        63 |       0.05  | future_mdd        | full             | dq_es               |  -3.45367   |  -2.77    |  0.00560568  | 0.314757   |      62 |
| shares   | baseline_2018 |      756 |        63 |       0.05  | future_mdd        | full             | dr_es_concentration |   6.33071   |   1.89598 |  0.0579627   | 0.314757   |      62 |
| shares   | baseline_2018 |      756 |        63 |       0.05  | future_tail_event | dr_only          | dr_es_concentration |  -0.608193  |  -2.19199 |  0.0283803   | 0.035453   |      62 |
| shares   | baseline_2018 |      756 |        63 |       0.05  | future_tail_event | dq_dr            | dr_es_concentration |  -1.20068   |  -1.80232 |  0.0714949   | 0.152554   |      62 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_es         | dr_only          | dr_es_concentration |  -0.597427  |  -2.10108 |  0.0356342   | 0.275282   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_es         | dq_dr            | dr_es_concentration |  -0.568992  |  -2.13567 |  0.0327062   | 0.276051   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_es         | full             | dr_es_concentration |  -1.70602   |  -1.75894 |  0.0785885   | 0.610842   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_var        | dr_only          | dr_es_concentration |  -0.400505  |  -2.23516 |  0.0254069   | 0.275203   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_var        | dq_dr            | dr_es_concentration |  -0.388445  |  -2.2391  |  0.0251492   | 0.275511   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_var        | full             | dr_es_concentration |  -1.28079   |  -1.84075 |  0.0656585   | 0.565855   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_rv_ann     | dr_only          | dr_es_concentration |  -2.01737   |  -1.92114 |  0.0547142   | 0.209641   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_rv_ann     | dq_dr            | dr_es_concentration |  -2.40091   |  -2.00384 |  0.0450875   | 0.21898    |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_mdd        | dr_only          | dr_es_concentration |  -0.688803  |  -2.19805 |  0.0279456   | 0.188581   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_mdd        | dq_dr            | dr_es_concentration |  -0.604859  |  -1.81547 |  0.0694512   | 0.192033   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_mdd        | dq_dr_current_es | dr_es_concentration |  -1.93146   |  -2.05662 |  0.0397231   | 0.218865   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_mdd        | full             | dr_es_concentration |  -3.2084    |  -1.84701 |  0.0647453   | 0.387484   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_tail_event | dr_only          | dr_es_concentration |  -4.49999   |  -3.59344 |  0.000326337 | 0.120799   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_tail_event | dq_dr            | dq_es               |   2.43631   |   4.64335 |  3.4281e-06  | 0.210556   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_tail_event | dq_dr            | dr_es_concentration |  -7.99412   |  -5.61584 |  1.95607e-08 | 0.210556   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_tail_event | dq_dr_current_es | dq_es               |   2.21858   |   3.03383 |  0.00241469  | 0.214829   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_tail_event | dq_dr_current_es | dr_es_concentration | -12.315     |  -1.90087 |  0.0573187   | 0.214829   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.025 | future_tail_event | full             | dr_es_concentration | -31.9009    |  -2.8155  |  0.00487017  | 0.316547   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_es         | dr_only          | dr_es_concentration |  -0.270941  |  -1.94913 |  0.0512803   | 0.221432   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_es         | dq_dr            | dr_es_concentration |  -0.221031  |  -2.02665 |  0.0426985   | 0.253602   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_es         | dq_dr_current_es | dr_es_concentration |  -0.898838  |  -1.85726 |  0.0632743   | 0.280874   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_es         | full             | dr_es_concentration |  -1.65732   |  -2.14532 |  0.0319275   | 0.658238   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_var        | dr_only          | dr_es_concentration |  -0.134269  |  -2.09379 |  0.0362787   | 0.167218   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_var        | dq_dr            | dr_es_concentration |  -0.111413  |  -1.95642 |  0.0504153   | 0.187963   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_var        | dq_dr_current_es | dr_es_concentration |  -0.553312  |  -1.84043 |  0.0657046   | 0.223607   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_var        | full             | dr_es_concentration |  -0.99086   |  -2.03917 |  0.0414332   | 0.412836   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_rv_ann     | dr_only          | dr_es_concentration |  -1.53941   |  -1.86899 |  0.061624    | 0.214619   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_rv_ann     | dq_dr            | dr_es_concentration |  -1.44404   |  -1.92847 |  0.0537969   | 0.218146   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_mdd        | dr_only          | dr_es_concentration |  -0.433133  |  -1.68032 |  0.0928944   | 0.1311     |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_mdd        | dq_dr_current_es | dq_es               |  -0.349278  |  -2.13146 |  0.0330513   | 0.216987   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_mdd        | dq_dr_current_es | dr_es_concentration |  -2.26155   |  -2.40401 |  0.0162163   | 0.216987   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_mdd        | full             | dr_es_concentration |  -3.94635   |  -2.35531 |  0.0185074   | 0.447551   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_tail_event | dr_only          | dr_es_concentration |  -3.3821    |  -4.06522 |  4.79864e-05 | 0.11871    |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_tail_event | dq_dr            | dr_es_concentration |  -4.15121   |  -3.88807 |  0.000101043 | 0.144992   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_tail_event | dq_dr_current_es | dr_es_concentration | -15.2053    |  -2.15177 |  0.0314153   | 0.169948   |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_tail_event | full             | dq_es               |   8.29308   |   1.96751 |  0.0491242   | 0.25593    |      52 |
| shares   | baseline_2018 |     1008 |        21 |       0.05  | future_tail_event | full             | dr_es_concentration | -31.8017    |  -3.23302 |  0.0012249   | 0.25593    |      52 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_es         | dq_only          | dq_es               |  -0.595998  | -11.07    |  1.75389e-28 | 0.786144   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_es         | dr_only          | dr_es_concentration |  -0.832621  |  -5.6375  |  1.72535e-08 | 0.725428   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_es         | dq_dr            | dq_es               |  -0.380853  |  -4.12005 |  3.78788e-05 | 0.861892   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_es         | dq_dr            | dr_es_concentration |  -0.412659  |  -3.17229 |  0.00151239  | 0.861892   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_es         | dq_dr_current_es | dq_es               |  -0.389199  |  -3.95663 |  7.60138e-05 | 0.862978   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_es         | full             | dq_es               |  -0.25422   |  -1.72703 |  0.0841621   | 0.91787    |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_var        | dq_only          | dq_es               |  -0.164378  | -10.2105  |  1.77901e-24 | 0.381466   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_var        | dr_only          | dr_es_concentration |  -0.2599    |  -7.42083 |  1.16388e-13 | 0.450887   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_var        | dq_dr            | dr_es_concentration |  -0.184998  |  -2.25294 |  0.0242629   | 0.478579   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_var        | full             | dr_es_concentration |  -0.996793  |  -1.67084 |  0.0947536   | 0.558576   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_rv_ann     | dq_only          | dq_es               |  -1.94568   | -11.36    |  6.61722e-30 | 0.659702   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_rv_ann     | dr_only          | dr_es_concentration |  -2.77603   |  -4.80989 |  1.51013e-06 | 0.634952   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_rv_ann     | dq_dr            | dq_es               |  -1.17234   |  -3.34287 |  0.000829174 | 0.736765   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_rv_ann     | dq_dr            | dr_es_concentration |  -1.48331   |  -2.50266 |  0.0123264   | 0.736765   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_rv_ann     | dq_dr_current_es | dq_es               |  -1.29121   |  -3.4554  |  0.000549482 | 0.754106   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_mdd        | dq_only          | dq_es               |  -1.01929   | -11.6029  |  3.98425e-31 | 0.497234   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_mdd        | dr_only          | dr_es_concentration |  -1.20817   |  -4.7572  |  1.96301e-06 | 0.330302   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_mdd        | dq_dr            | dq_es               |  -0.916005  |  -4.41702 |  1.00069e-05 | 0.50101    |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_mdd        | dq_dr_current_es | dq_es               |  -0.859536  |  -4.07265 |  4.64807e-05 | 0.511757   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_tail_event | dr_only          | dr_es_concentration |  -4.22201   |  -2.07142 |  0.0383194   | 0.125642   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_tail_event | dq_dr            | dq_es               |   4.63429   |   2.54004 |  0.011084    | 0.261744   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_tail_event | dq_dr            | dr_es_concentration |  -9.33218   |  -2.92905 |  0.00339996  | 0.261744   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_tail_event | dq_dr_current_es | dq_es               |   4.92014   |   2.44935 |  0.0143114   | 0.270322   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_tail_event | full             | dq_es               |   9.52021   |   2.13247 |  0.0329682   | 0.428434   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.025 | future_tail_event | full             | dr_es_concentration | -30.3007    |  -2.26762 |  0.0233524   | 0.428434   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_es         | dq_only          | dq_es               |  -0.422226  |  -7.46862 |  8.10408e-14 | 0.67157    |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_es         | dr_only          | dr_es_concentration |  -0.295625  |  -3.15572 |  0.00160104  | 0.472636   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_es         | dq_dr            | dq_es               |  -0.329477  |  -4.21454 |  2.50291e-05 | 0.722443   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_es         | dq_dr            | dr_es_concentration |  -0.124092  |  -1.86593 |  0.0620517   | 0.722443   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_es         | dq_dr_current_es | dq_es               |  -0.334351  |  -4.00578 |  6.1812e-05  | 0.723563   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_var        | dq_only          | dq_es               |  -0.0851916 |  -3.46072 |  0.00053874  | 0.151311   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_var        | dr_only          | dr_es_concentration |  -0.0611058 |  -2.81899 |  0.00481754  | 0.11176    |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_rv_ann     | dq_only          | dq_es               |  -2.43106   |  -6.21536 |  5.12081e-10 | 0.635448   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_rv_ann     | dr_only          | dr_es_concentration |  -1.72843   |  -2.61528 |  0.00891532  | 0.461144   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_rv_ann     | dq_dr            | dq_es               |  -1.86485   |  -4.02272 |  5.75295e-05 | 0.689562   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_rv_ann     | dq_dr            | dr_es_concentration |  -0.757548  |  -1.72928 |  0.0837583   | 0.689562   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_rv_ann     | dq_dr_current_es | dq_es               |  -1.98429   |  -3.80946 |  0.00013927  | 0.708771   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_mdd        | dq_only          | dq_es               |  -1.19966   |  -7.09815 |  1.26442e-12 | 0.424974   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_mdd        | dr_only          | dr_es_concentration |  -0.63336   |  -2.06356 |  0.0390591   | 0.170057   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_mdd        | dq_dr            | dq_es               |  -1.1889    |  -3.733   |  0.000189215 | 0.425028   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_mdd        | dq_dr_current_es | dq_es               |  -1.19056   |  -3.46281 |  0.000534571 | 0.425038   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_tail_event | full             | dq_es               |  10.9676    |   2.14395 |  0.0320371   | 0.213487   |      50 |
| shares   | baseline_2018 |     1008 |        63 |       0.05  | future_tail_event | full             | dr_es_concentration | -27.2918    |  -2.01696 |  0.0437001   | 0.213487   |      50 |
| shares   | full_2015     |      504 |        21 |       0.025 | future_es         | dq_only          | dq_es               |   0.0183941 |   1.71019 |  0.0872309   | 0.00952434 |     112 |
| shares   | full_2015     |      504 |        21 |       0.025 | future_es         | dr_only          | dr_es_concentration |   0.0357613 |   2.29656 |  0.0216439   | 0.0324542  |     112 |
| shares   | full_2015     |      504 |        21 |       0.025 | future_es         | dq_dr            | dr_es_concentration |   0.0391771 |   1.89626 |  0.0579256   | 0.0328985  |     112 |
| shares   | full_2015     |      504 |        21 |       0.025 | future_var        | dr_only          | dr_es_concentration |   0.0284119 |   2.61099 |  0.00902799  | 0.0441604  |     112 |
| shares   | full_2015     |      504 |        21 |       0.025 | future_var        | dq_dr            | dr_es_concentration |   0.034683  |   2.36774 |  0.0178973   | 0.047389   |     112 |
| shares   | full_2015     |      504 |        21 |       0.025 | future_rv_ann     | dq_only          | dq_es               |   0.13896   |   2.32474 |  0.0200857   | 0.0286556  |     112 |
| shares   | full_2015     |      504 |        21 |       0.025 | future_rv_ann     | dr_only          | dr_es_concentration |   0.261198  |   3.57346 |  0.000352292 | 0.0912704  |     112 |
| shares   | full_2015     |      504 |        21 |       0.025 | future_rv_ann     | dq_dr            | dr_es_concentration |   0.281028  |   2.97895 |  0.00289235  | 0.0920599  |     112 |
| shares   | full_2015     |      504 |        21 |       0.025 | future_mdd        | dr_only          | dr_es_concentration |   0.0668451 |   2.42893 |  0.0151434   | 0.0480344  |     112 |
| shares   | full_2015     |      504 |        21 |       0.025 | future_mdd        | dq_dr            | dr_es_concentration |   0.0937001 |   2.73452 |  0.00624714  | 0.0596688  |     112 |
| shares   | full_2015     |      504 |        21 |       0.025 | future_mdd        | dq_dr_current_es | dq_es               |  -0.0947462 |  -1.86012 |  0.0628682   | 0.0709398  |     112 |
| shares   | full_2015     |      504 |        21 |       0.025 | future_mdd        | full             | dr_es_concentration |  -0.285716  |  -1.73014 |  0.0836059   | 0.364069   |     112 |
| shares   | full_2015     |      504 |        21 |       0.025 | future_tail_event | dq_only          | dq_es               |   0.49957   |   1.81232 |  0.0699371   | 0.033976   |     112 |
| shares   | full_2015     |      504 |        21 |       0.025 | future_tail_event | dq_dr            | dq_es               |   0.710596  |   2.06934 |  0.0385142   | 0.0430736  |     112 |
| shares   | full_2015     |      504 |        21 |       0.025 | future_tail_event | full             | dr_es_concentration |  -5.72586   |  -5.71305 |  1.10969e-08 | 0.235809   |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_es         | dq_only          | dq_es               |   0.0237585 |   2.24953 |  0.0244791   | 0.0293606  |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_es         | dr_only          | dr_es_concentration |   0.0311748 |   2.97665 |  0.00291417  | 0.0495048  |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_es         | dq_dr            | dr_es_concentration |   0.0276405 |   2.39437 |  0.016649    | 0.0502415  |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_var        | dq_only          | dq_es               |   0.0134869 |   1.91984 |  0.0548776   | 0.0264772  |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_var        | dr_only          | dr_es_concentration |   0.0247056 |   3.47851 |  0.000504212 | 0.0870068  |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_var        | dq_dr            | dr_es_concentration |   0.028753  |   2.94931 |  0.00318488  | 0.0897103  |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_var        | full             | dr_es_concentration |  -0.087439  |  -1.89333 |  0.0583134   | 0.393146   |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_rv_ann     | dq_only          | dq_es               |   0.225638  |   3.09408 |  0.00197424  | 0.0647606  |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_rv_ann     | dr_only          | dr_es_concentration |   0.28475   |   4.02335 |  5.73767e-05 | 0.101001   |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_rv_ann     | dq_dr            | dr_es_concentration |   0.241405  |   2.89666 |  0.00377161  | 0.103711   |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_rv_ann     | full             | dr_es_concentration |  -0.907402  |  -1.84224 |  0.0654394   | 0.54274    |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_mdd        | dq_only          | dq_es               |   0.0466505 |   1.65892 |  0.0971319   | 0.0222443  |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_mdd        | dr_only          | dr_es_concentration |   0.0770537 |   2.80031 |  0.00510537  | 0.0594303  |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_mdd        | dq_dr            | dr_es_concentration |   0.0837966 |   2.44544 |  0.0144674   | 0.0599572  |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_mdd        | full             | dr_es_concentration |  -0.349996  |  -1.8255  |  0.0679252   | 0.338161   |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_tail_event | dq_only          | dq_es               |   0.676476  |   2.25337 |  0.024236    | 0.0488093  |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_tail_event | dq_dr            | dq_es               |   1.3253    |   3.43895 |  0.000583977 | 0.100794   |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_tail_event | dq_dr            | dr_es_concentration |  -0.963108  |  -2.56572 |  0.0102962   | 0.100794   |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_tail_event | dq_dr_current_es | dq_es               |   1.66081   |   3.73943 |  0.00018444  | 0.116346   |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_tail_event | full             | dq_es               |   3.21404   |   2.51366 |  0.0119487   | 0.180607   |     112 |
| shares   | full_2015     |      504 |        21 |       0.05  | future_tail_event | full             | dr_es_concentration |  -3.73031   |  -2.54826 |  0.0108262   | 0.180607   |     112 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_es         | dq_only          | dq_es               |   0.0250988 |   1.77387 |  0.0760853   | 0.0166522  |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_es         | dr_only          | dr_es_concentration |   0.0413331 |   2.00963 |  0.0444702   | 0.0408092  |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_es         | full             | dr_es_concentration |  -0.161962  |  -1.98945 |  0.0466521   | 0.298604   |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_var        | dr_only          | dr_es_concentration |   0.0305857 |   2.77807 |  0.00546836  | 0.118025   |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_var        | dq_dr            | dr_es_concentration |   0.0336171 |   2.43339 |  0.0149581   | 0.119644   |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_var        | full             | dr_es_concentration |  -0.117196  |  -3.90649 |  9.36448e-05 | 0.423879   |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_rv_ann     | dq_only          | dq_es               |   0.13334   |   2.07085 |  0.0383727   | 0.0322954  |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_rv_ann     | dr_only          | dr_es_concentration |   0.252007  |   3.05355 |  0.00226151  | 0.104242   |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_rv_ann     | dq_dr            | dr_es_concentration |   0.277004  |   2.42745 |  0.0152053   | 0.105674   |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_rv_ann     | full             | dr_es_concentration |  -0.739612  |  -2.71431 |  0.00664138  | 0.390367   |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_mdd        | dr_only          | dr_es_concentration |   0.120738  |   1.8562  |  0.0634253   | 0.0601952  |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_mdd        | dq_dr            | dr_es_concentration |   0.177953  |   2.24253 |  0.0249269   | 0.0790633  |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_mdd        | dq_dr_current_es | dq_es               |  -0.194451  |  -1.68617 |  0.091764    | 0.0972227  |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_mdd        | full             | dq_es               |  -0.67199   |  -1.79648 |  0.0724178   | 0.436066   |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_mdd        | full             | dr_es_concentration |  -0.810234  |  -4.90985 |  9.11469e-07 | 0.436066   |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_tail_event | dq_only          | dq_es               |   0.489183  |   1.66237 |  0.0964377   | 0.0310858  |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_tail_event | dq_dr            | dq_es               |   0.909739  |   1.80629 |  0.0708724   | 0.0631562  |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_tail_event | dq_dr_current_es | dr_es_concentration |  -2.60876   |  -2.38684 |  0.0169938   | 0.121642   |     110 |
| shares   | full_2015     |      504 |        63 |       0.025 | future_tail_event | full             | dr_es_concentration |  -6.72917   |  -4.36045 |  1.29795e-05 | 0.280719   |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_es         | dq_only          | dq_es               |   0.0299168 |   2.2159  |  0.0266987   | 0.0495068  |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_es         | dr_only          | dr_es_concentration |   0.0354489 |   2.61377 |  0.00895485  | 0.0680848  |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_es         | dq_dr            | dr_es_concentration |   0.0281192 |   1.79771 |  0.0722223   | 0.0710215  |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_var        | dq_only          | dq_es               |   0.0155242 |   1.87155 |  0.061269    | 0.0580462  |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_var        | dr_only          | dr_es_concentration |   0.024958  |   2.99418 |  0.00275181  | 0.146955   |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_var        | dq_dr            | dr_es_concentration |   0.0276598 |   2.34193 |  0.0191842   | 0.148692   |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_var        | full             | dr_es_concentration |  -0.110845  |  -2.99352 |  0.00275778  | 0.41836    |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_rv_ann     | dq_only          | dq_es               |   0.215947  |   2.82437 |  0.0047373   | 0.0722321  |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_rv_ann     | dr_only          | dr_es_concentration |   0.275558  |   3.52349 |  0.00042591  | 0.115206   |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_rv_ann     | dq_dr            | dr_es_concentration |   0.242157  |   2.34172 |  0.019195    | 0.116914   |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_mdd        | dr_only          | dr_es_concentration |   0.146289  |   2.35603 |  0.0184713   | 0.0816822  |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_mdd        | dq_dr            | dr_es_concentration |   0.178676  |   2.33692 |  0.0194432   | 0.0857213  |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_mdd        | full             | dr_es_concentration |  -0.829966  |  -2.87923 |  0.00398644  | 0.38487    |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_tail_event | dq_only          | dq_es               |   0.377993  |   1.95311 |  0.0508068   | 0.0380741  |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_tail_event | dq_dr            | dq_es               |   1.06371   |   3.19115 |  0.00141709  | 0.164488   |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_tail_event | dq_dr            | dr_es_concentration |  -0.982013  |  -2.66558 |  0.00768551  | 0.164488   |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_tail_event | dq_dr_current_es | dq_es               |   1.14153   |   3.58852 |  0.000332556 | 0.166691   |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_tail_event | full             | dq_es               |   3.40019   |   4.46878 |  7.86656e-06 | 0.265062   |     110 |
| shares   | full_2015     |      504 |        63 |       0.05  | future_tail_event | full             | dr_es_concentration |  -3.20418   |  -4.20726 |  2.58486e-05 | 0.265062   |     110 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_es         | dq_only          | dq_es               |   0.0249112 |   2.07341 |  0.0381344   | 0.0159467  |     100 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_es         | dr_only          | dr_es_concentration |   0.0356868 |   2.61126 |  0.00902101  | 0.0250955  |     100 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_es         | full             | dr_es_concentration |  -0.410667  |  -2.50087 |  0.0123889   | 0.603696   |     100 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_var        | dq_only          | dq_es               |   0.0198048 |   2.01255 |  0.0441624   | 0.021775   |     100 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_var        | dr_only          | dr_es_concentration |   0.0304028 |   2.97205 |  0.00295822  | 0.0393502  |     100 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_var        | dq_dr            | dr_es_concentration |   0.0327065 |   1.83222 |  0.0669185   | 0.0394941  |     100 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_var        | full             | dr_es_concentration |  -0.306447  |  -2.78219 |  0.00539935  | 0.56613    |     100 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_rv_ann     | dq_only          | dq_es               |   0.206097  |   3.1956  |  0.00139541  | 0.0578243  |     100 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_rv_ann     | dr_only          | dr_es_concentration |   0.286428  |   4.16862 |  3.06444e-05 | 0.0856438  |     100 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_rv_ann     | dq_dr            | dr_es_concentration |   0.263365  |   2.28725 |  0.0221813   | 0.0859974  |     100 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_rv_ann     | full             | dr_es_concentration |  -2.02134   |  -3.10458 |  0.00190546  | 0.573847   |     100 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_mdd        | dr_only          | dr_es_concentration |   0.0795957 |   2.77178 |  0.00557513  | 0.0531636  |     100 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_mdd        | dq_dr            | dr_es_concentration |   0.106171  |   2.34072 |  0.0192468   | 0.0569382  |     100 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_mdd        | full             | dr_es_concentration |  -0.82452   |  -2.97983 |  0.00288406  | 0.460911   |     100 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_tail_event | dq_only          | dq_es               |   0.540027  |   1.9245  |  0.0542919   | 0.0381644  |     100 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_tail_event | dq_dr            | dq_es               |   0.907872  |   2.66336 |  0.00773644  | 0.0494424  |     100 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_tail_event | dq_dr_current_es | dq_es               |   1.98967   |   3.32812 |  0.000874346 | 0.101727   |     100 |
| shares   | full_2015     |      756 |        21 |       0.025 | future_tail_event | full             | dr_es_concentration |  -5.61024   |  -3.68882 |  0.000225296 | 0.261317   |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_es         | dq_only          | dq_es               |   0.025912  |   2.56147 |  0.0104229   | 0.0303695  |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_es         | dr_only          | dr_es_concentration |   0.029539  |   2.8923  |  0.00382437  | 0.0355616  |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_es         | full             | dr_es_concentration |  -0.414579  |  -2.7749  |  0.00552187  | 0.585309   |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_var        | dq_only          | dq_es               |   0.0196137 |   2.35211 |  0.0186673   | 0.0489662  |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_var        | dr_only          | dr_es_concentration |   0.026187  |   3.31807 |  0.000906426 | 0.0786511  |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_var        | dq_dr            | dr_es_concentration |   0.0271718 |   2.3913  |  0.0167889   | 0.0787113  |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_var        | full             | dr_es_concentration |  -0.22519   |  -2.56501 |  0.0103172   | 0.425139   |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_rv_ann     | dq_only          | dq_es               |   0.258011  |   3.82108 |  0.000132868 | 0.073834   |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_rv_ann     | dr_only          | dr_es_concentration |   0.281548  |   4.098   |  4.16732e-05 | 0.0792214  |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_rv_ann     | dq_dr            | dr_es_concentration |   0.178282  |   1.82205 |  0.0684477   | 0.0849923  |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_rv_ann     | full             | dr_es_concentration |  -2.6438    |  -2.97869 |  0.00289487  | 0.602828   |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_mdd        | dq_only          | dq_es               |   0.0608298 |   2.03538 |  0.0418124   | 0.0329901  |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_mdd        | dr_only          | dr_es_concentration |   0.0817876 |   2.81132 |  0.00493383  | 0.053738   |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_mdd        | dq_dr            | dr_es_concentration |   0.0858971 |   1.91721 |  0.0552109   | 0.0538115  |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_mdd        | full             | dr_es_concentration |  -0.809638  |  -2.40823 |  0.0160299   | 0.470275   |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_tail_event | dq_only          | dq_es               |   0.575641  |   1.8222  |  0.0684252   | 0.0336504  |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_tail_event | dq_dr            | dq_es               |   1.27578   |   2.47073 |  0.0134839   | 0.0606054  |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_tail_event | dq_dr            | dr_es_concentration |  -0.915744  |  -1.76033 |  0.0783518   | 0.0606054  |     100 |
| shares   | full_2015     |      756 |        21 |       0.05  | future_tail_event | dq_dr_current_es | dq_es               |   1.78671   |   3.3128  |  0.00092368  | 0.104892   |     100 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_es         | dr_only          | dr_es_concentration |   0.0378153 |   1.92845 |  0.0537996   | 0.0266807  |      98 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_es         | full             | dq_es               |   0.146539  |   2.40178 |  0.0163156   | 0.248994   |      98 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_es         | full             | dr_es_concentration |  -0.34038   |  -2.08665 |  0.0369196   | 0.248994   |      98 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_var        | dq_only          | dq_es               |   0.0281041 |   2.4565  |  0.0140298   | 0.102462   |      98 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_var        | dr_only          | dr_es_concentration |   0.0352315 |   3.00722 |  0.00263646  | 0.125225   |      98 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_var        | dq_dr            | dr_es_concentration |   0.0272159 |   1.77428 |  0.076017    | 0.128741   |      98 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_var        | full             | dr_es_concentration |  -0.181061  |  -2.63562 |  0.00839837  | 0.362685   |      98 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_rv_ann     | dq_only          | dq_es               |   0.196416  |   2.52937 |  0.0114267   | 0.0645329  |      98 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_rv_ann     | dr_only          | dr_es_concentration |   0.260523  |   3.29748 |  0.000975549 | 0.0882923  |      98 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_rv_ann     | full             | dq_es               |   0.381196  |   1.78081 |  0.074943    | 0.289933   |      98 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_rv_ann     | full             | dr_es_concentration |  -1.50124   |  -2.56542 |  0.0103051   | 0.289933   |      98 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_mdd        | dr_only          | dr_es_concentration |   0.147459  |   2.1277  |  0.0333616   | 0.0712028  |      98 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_mdd        | dq_dr            | dr_es_concentration |   0.168731  |   1.83628 |  0.0663157   | 0.0720066  |      98 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_mdd        | full             | dr_es_concentration |  -1.48517   |  -4.16818 |  3.07039e-05 | 0.361678   |      98 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_tail_event | dq_only          | dq_es               |   0.963451  |   2.71052 |  0.00671769  | 0.127141   |      98 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_tail_event | dq_dr            | dq_es               |   1.78703   |   3.3939  |  0.000689048 | 0.177535   |      98 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_tail_event | dq_dr_current_es | dq_es               |   2.34758   |   3.23531 |  0.0012151   | 0.192399   |      98 |
| shares   | full_2015     |      756 |        63 |       0.025 | future_tail_event | full             | dr_es_concentration |  -5.43121   |  -2.19711 |  0.0280123   | 0.281417   |      98 |
| shares   | full_2015     |      756 |        63 |       0.05  | future_es         | dq_only          | dq_es               |   0.0313522 |   2.16765 |  0.0301855   | 0.0480633  |      98 |
| shares   | full_2015     |      756 |        63 |       0.05  | future_es         | dr_only          | dr_es_concentration |   0.0324908 |   2.14857 |  0.0316682   | 0.0462425  |      98 |
| shares   | full_2015     |      756 |        63 |       0.05  | future_var        | dq_only          | dq_es               |   0.0248776 |   2.52462 |  0.0115822   | 0.134055   |      98 |
| shares   | full_2015     |      756 |        63 |       0.05  | future_var        | dr_only          | dr_es_concentration |   0.0283264 |   2.96737 |  0.00300359  | 0.155701   |      98 |
| shares   | full_2015     |      756 |        63 |       0.05  | future_var        | dq_dr            | dr_es_concentration |   0.0209097 |   1.74452 |  0.0810685   | 0.160547   |      98 |
| shares   | full_2015     |      756 |        63 |       0.05  | future_var        | full             | dr_es_concentration |  -0.18626   |  -2.00965 |  0.0444684   | 0.372002   |      98 |
| shares   | full_2015     |      756 |        63 |       0.05  | future_rv_ann     | dq_only          | dq_es               |   0.240153  |   2.99907 |  0.00270808  | 0.0794529  |      98 |
| shares   | full_2015     |      756 |        63 |       0.05  | future_rv_ann     | dr_only          | dr_es_concentration |   0.255871  |   3.02654 |  0.00247368  | 0.0808009  |      98 |
| shares   | full_2015     |      756 |        63 |       0.05  | future_mdd        | dq_only          | dq_es               |   0.122553  |   1.70014 |  0.0891038   | 0.052084   |      98 |
| shares   | full_2015     |      756 |        63 |       0.05  | future_mdd        | dr_only          | dr_es_concentration |   0.156665  |   2.28166 |  0.0225092   | 0.0762507  |      98 |
| shares   | full_2015     |      756 |        63 |       0.05  | future_mdd        | dq_dr            | dr_es_concentration |   0.157841  |   1.67017 |  0.0948858   | 0.0762526  |      98 |
| shares   | full_2015     |      756 |        63 |       0.05  | future_mdd        | full             | dr_es_concentration |  -1.5694    |  -2.28847 |  0.0221099   | 0.319553   |      98 |
| shares   | full_2015     |     1008 |        21 |       0.025 | future_rv_ann     | dq_only          | dq_es               |   0.202574  |   2.02901 |  0.0424571   | 0.0416198  |      88 |
| shares   | full_2015     |     1008 |        21 |       0.025 | future_rv_ann     | dr_only          | dr_es_concentration |   0.238831  |   2.43518 |  0.0148842   | 0.0484667  |      88 |
| shares   | full_2015     |     1008 |        21 |       0.025 | future_tail_event | dq_dr            | dq_es               |   1.3327    |   1.7613  |  0.0781875   | 0.0226856  |      88 |
| shares   | full_2015     |     1008 |        21 |       0.025 | future_tail_event | dq_dr_current_es | dq_es               |   3.35484   |   5.32516 |  1.00862e-07 | 0.172561   |      88 |
| shares   | full_2015     |     1008 |        21 |       0.025 | future_tail_event | dq_dr_current_es | dr_es_concentration |   4.12336   |   2.56072 |  0.0104456   | 0.172561   |      88 |
| shares   | full_2015     |     1008 |        21 |       0.025 | future_tail_event | full             | dq_es               |   6.79321   |   2.46041 |  0.013878    | 0.320439   |      88 |
| shares   | full_2015     |     1008 |        21 |       0.05  | future_es         | full             | dr_es_concentration |  -0.461691  |  -1.95363 |  0.050745    | 0.541487   |      88 |
| shares   | full_2015     |     1008 |        21 |       0.05  | future_var        | dq_only          | dq_es               |   0.0194173 |   1.645   |  0.0999698   | 0.0356253  |      88 |
| shares   | full_2015     |     1008 |        21 |       0.05  | future_var        | dr_only          | dr_es_concentration |   0.0211314 |   1.85435 |  0.0636897   | 0.0410246  |      88 |
| shares   | full_2015     |     1008 |        21 |       0.05  | future_var        | full             | dr_es_concentration |  -0.276715  |  -1.88732 |  0.059117    | 0.373788   |      88 |
| shares   | full_2015     |     1008 |        21 |       0.05  | future_rv_ann     | dq_only          | dq_es               |   0.237255  |   2.31148 |  0.0208065   | 0.0468461  |      88 |
| shares   | full_2015     |     1008 |        21 |       0.05  | future_rv_ann     | dr_only          | dr_es_concentration |   0.225315  |   2.16557 |  0.030344    | 0.0410801  |      88 |
| shares   | full_2015     |     1008 |        21 |       0.05  | future_rv_ann     | full             | dr_es_concentration |  -3.37399   |  -2.2076  |  0.0272721   | 0.5571     |      88 |
| shares   | full_2015     |     1008 |        21 |       0.05  | future_mdd        | full             | dr_es_concentration |  -1.14294   |  -2.09921 |  0.0357985   | 0.386523   |      88 |
| shares   | full_2015     |     1008 |        21 |       0.05  | future_tail_event | dq_dr            | dq_es               |   3.03974   |   3.72205 |  0.000197613 | 0.0903349  |      88 |
| shares   | full_2015     |     1008 |        21 |       0.05  | future_tail_event | dq_dr            | dr_es_concentration |  -3.10969   |  -4.07072 |  4.68689e-05 | 0.0903349  |      88 |
| shares   | full_2015     |     1008 |        21 |       0.05  | future_tail_event | dq_dr_current_es | dq_es               |   2.69018   |   3.06925 |  0.00214598  | 0.12686    |      88 |
| shares   | full_2015     |     1008 |        21 |       0.05  | future_tail_event | full             | dq_es               |   5.00347   |   1.80654 |  0.0708334   | 0.209563   |      88 |
| shares   | full_2015     |     1008 |        21 |       0.05  | future_tail_event | full             | dr_es_concentration |  -6.46893   |  -2.56823 |  0.0102221   | 0.209563   |      88 |
| shares   | full_2015     |     1008 |        63 |       0.025 | future_tail_event | dq_dr_current_es | dq_es               |   4.7274    |   2.6407  |  0.00827351  | 0.184297   |      86 |
| shares   | full_2015     |     1008 |        63 |       0.025 | future_tail_event | full             | dq_es               |  11.459     |   3.55455 |  0.000378623 | 0.367331   |      86 |
| shares   | full_2015     |     1008 |        63 |       0.025 | future_tail_event | full             | dr_es_concentration |  -6.03483   |  -1.85467 |  0.0636433   | 0.367331   |      86 |
