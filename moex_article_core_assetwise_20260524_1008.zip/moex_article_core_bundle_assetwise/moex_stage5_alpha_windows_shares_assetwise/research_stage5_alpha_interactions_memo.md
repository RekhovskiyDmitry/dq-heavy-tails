# Stage 5 assetwise alpha interactions memo
## Inputs
- rolling: `moex_stage2_alpha_windows_shares_parallel/02_stage2_rolling_metrics.csv`
- alpha: `moex_tail_stage4_main_shares_raw/03_tail_alpha_estimates.csv`

## Linked rows
- rows: 1,944
- periods: {'full_2015': 1188, 'baseline_2018': 756}
- match ratio min/median/max: 0.958 / 1.000 / 1.000
- lag days mean/max: 12.01 / 34
- median portfolio alpha: 2.722
- mean P(alpha<1): 0.000068
- mean P(alpha>2): 0.798357

## Interaction summary
| dependent         | spec                                         | param        |   n_models |   sig10 |   sig5 |   pos_sig10 |   neg_sig10 |   median_coef |   median_t_hac |   mean_r2 |   min_pvalue |
|:------------------|:---------------------------------------------|:-------------|-----------:|--------:|-------:|------------:|------------:|--------------:|---------------:|----------:|-------------:|
| future_es         | interact_alpha_heaviness_below2              | z_dq_x_heavy |         16 |       5 |      3 |           3 |           2 |   0.000635417 |      0.475582  | 0.0449992 | 1.53382e-23  |
| future_es         | interact_alpha_heaviness_below2              | z_dr_x_heavy |         16 |       7 |      6 |           2 |           5 |   0.000950193 |      0.364661  | 0.0449992 | 1.09065e-19  |
| future_es         | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |         16 |       4 |      4 |           2 |           2 |  -0.00614658  |     -0.652082  | 0.0951283 | 4.88733e-05  |
| future_es         | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy |         16 |       7 |      6 |           1 |           6 |  -0.0106306   |     -0.903894  | 0.0951283 | 2.44921e-12  |
| future_es         | interact_alpha_heaviness_inv                 | z_dq_x_heavy |         24 |       7 |      4 |           0 |           7 |  -0.00876901  |     -1.19792   | 0.183455  | 0.0381316    |
| future_es         | interact_alpha_heaviness_inv                 | z_dr_x_heavy |         24 |      11 |      4 |          10 |           1 |   0.0108998   |      1.31298   | 0.183455  | 0.000170049  |
| future_es         | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy |         24 |       5 |      2 |           0 |           5 |  -0.00776383  |     -1.05312   | 0.243551  | 0.00137213   |
| future_es         | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |         24 |       5 |      1 |           4 |           1 |   0.00805278  |      0.660342  | 0.243551  | 0.000125707  |
| future_es         | interact_alpha_heaviness_q25_below2          | z_dq_x_heavy |         24 |       6 |      4 |           3 |           3 |  -0.00133056  |     -0.120071  | 0.141698  | 0.00893021   |
| future_es         | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy |         24 |       8 |      5 |           2 |           6 |  -0.0120888   |     -0.975505  | 0.141698  | 0.000438229  |
| future_es         | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy |         24 |      11 |      8 |           6 |           5 |   6.90536e-05 |     -0.0136706 | 0.221172  | 0.000163722  |
| future_es         | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy |         24 |      11 |      7 |           2 |           9 |  -0.0349569   |     -1.41202   | 0.221172  | 9.70517e-05  |
| future_mdd        | interact_alpha_heaviness_below2              | z_dq_x_heavy |         16 |       9 |      9 |           4 |           5 |  -0.0185549   |     -1.06428   | 0.0740739 | 2.07694e-41  |
| future_mdd        | interact_alpha_heaviness_below2              | z_dr_x_heavy |         16 |      11 |     10 |           7 |           4 |   0.00159116  |      0.0549415 | 0.0740739 | 1.50373e-68  |
| future_mdd        | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |         16 |       8 |      5 |           4 |           4 |  -0.0179655   |     -0.68007   | 0.126177  | 1.61134e-08  |
| future_mdd        | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy |         16 |       8 |      8 |           4 |           4 |  -0.0125091   |     -0.258493  | 0.126177  | 2.16143e-36  |
| future_mdd        | interact_alpha_heaviness_inv                 | z_dq_x_heavy |         24 |      12 |      8 |           0 |          12 |  -0.0278228   |     -1.53662   | 0.184779  | 0.000719229  |
| future_mdd        | interact_alpha_heaviness_inv                 | z_dr_x_heavy |         24 |      11 |      7 |          10 |           1 |   0.0321584   |      1.45034   | 0.184779  | 0.000223385  |
| future_mdd        | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy |         24 |       7 |      3 |           0 |           7 |  -0.026739    |     -1.15269   | 0.222918  | 2.78631e-12  |
| future_mdd        | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |         24 |       6 |      4 |           5 |           1 |   0.0323352   |      0.60921   | 0.222918  | 9.04348e-05  |
| future_mdd        | interact_alpha_heaviness_q25_below2          | z_dq_x_heavy |         24 |       5 |      3 |           2 |           3 |  -0.0185989   |     -0.519294  | 0.144277  | 3.18553e-23  |
| future_mdd        | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy |         24 |       5 |      4 |           1 |           4 |  -0.0245644   |     -0.561797  | 0.144277  | 3.61998e-13  |
| future_mdd        | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy |         24 |       9 |      8 |           6 |           3 |  -0.018417    |     -0.438432  | 0.212364  | 4.2991e-14   |
| future_mdd        | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy |         24 |      13 |      9 |           1 |          12 |  -0.0816532   |     -1.39753   | 0.212364  | 7.63021e-09  |
| future_rv_ann     | interact_alpha_heaviness_below2              | z_dq_x_heavy |         16 |       8 |      8 |           7 |           1 |   0.0983808   |      1.4998    | 0.0701623 | 1.9707e-134  |
| future_rv_ann     | interact_alpha_heaviness_below2              | z_dr_x_heavy |         16 |       7 |      7 |           2 |           5 |  -0.0497468   |     -0.891804  | 0.0701623 | 1.0277e-123  |
| future_rv_ann     | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |         16 |       6 |      5 |           6 |           0 |   0.0596194   |      0.907097  | 0.129615  | 8.28449e-29  |
| future_rv_ann     | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy |         16 |       8 |      8 |           0 |           8 |  -0.085697    |     -1.78534   | 0.129615  | 2.19777e-91  |
| future_rv_ann     | interact_alpha_heaviness_inv                 | z_dq_x_heavy |         24 |      11 |      7 |           0 |          11 |  -0.0646686   |     -1.62224   | 0.217551  | 0.000422993  |
| future_rv_ann     | interact_alpha_heaviness_inv                 | z_dr_x_heavy |         24 |      12 |      8 |          10 |           2 |   0.0693209   |      1.57429   | 0.217551  | 9.75869e-05  |
| future_rv_ann     | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy |         24 |      10 |      8 |           0 |          10 |  -0.068503    |     -1.56215   | 0.287594  | 3.21895e-11  |
| future_rv_ann     | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |         24 |       7 |      4 |           7 |           0 |   0.0682203   |      1.12895   | 0.287594  | 9.02191e-05  |
| future_rv_ann     | interact_alpha_heaviness_q25_below2          | z_dq_x_heavy |         24 |       7 |      4 |           6 |           1 |   0.0344528   |      0.746443  | 0.167187  | 0.000200148  |
| future_rv_ann     | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy |         24 |       9 |      7 |           1 |           8 |  -0.101789    |     -1.35269   | 0.167187  | 4.80618e-07  |
| future_rv_ann     | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy |         24 |      10 |      9 |           8 |           2 |   0.0456732   |      0.428454  | 0.258787  | 5.19785e-07  |
| future_rv_ann     | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy |         24 |      12 |     11 |           1 |          11 |  -0.203774    |     -1.48792   | 0.258787  | 0.000247901  |
| future_tail_event | interact_alpha_heaviness_below2              | z_dq_x_heavy |         16 |       6 |      5 |           4 |           2 |   0.00810139  |      0.180724  | 0.157353  | 9.66079e-08  |
| future_tail_event | interact_alpha_heaviness_below2              | z_dr_x_heavy |         16 |       9 |      8 |           7 |           2 |   0.00720967  |      0.729415  | 0.157353  | 1.61764e-10  |
| future_tail_event | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |         16 |       2 |      1 |           2 |           0 |  -0.00409567  |     -0.084956  | 0.210724  | 8.74007e-05  |
| future_tail_event | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy |         16 |       7 |      7 |           5 |           2 |  -0.0759617   |     -0.268853  | 0.210724  | 2.9925e-05   |
| future_tail_event | interact_alpha_heaviness_inv                 | z_dq_x_heavy |         24 |      10 |      5 |           0 |          10 |  -0.139713    |     -1.32044   | 0.234965  | 1.42472e-05  |
| future_tail_event | interact_alpha_heaviness_inv                 | z_dr_x_heavy |         24 |       5 |      4 |           4 |           1 |   0.0813261   |      0.649613  | 0.234965  | 9.48838e-10  |
| future_tail_event | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy |         24 |       7 |      5 |           1 |           6 |  -0.135437    |     -0.927106  | 0.260073  | 1.06201e-16  |
| future_tail_event | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |         24 |       5 |      4 |           1 |           4 |  -0.00921932  |     -0.0419964 | 0.260073  | 0.000469174  |
| future_tail_event | interact_alpha_heaviness_q25_below2          | z_dq_x_heavy |         24 |       4 |      4 |           3 |           1 |   0.122757    |      0.875386  | 0.186172  | 0.000405814  |
| future_tail_event | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy |         24 |       9 |      6 |           1 |           8 |  -0.252014    |     -1.37305   | 0.186172  | 0.00142346   |
| future_tail_event | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy |         24 |       6 |      3 |           6 |           0 |   0.177512    |      0.756393  | 0.247341  | 1.1356e-12   |
| future_tail_event | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy |         24 |      11 |      8 |           0 |          11 |  -0.491759    |     -1.53405   | 0.247341  | 4.22018e-11  |
| future_var        | interact_alpha_heaviness_below2              | z_dq_x_heavy |         16 |       6 |      5 |           3 |           3 |  -0.00053456  |     -0.435647  | 0.094943  | 1.22709e-116 |
| future_var        | interact_alpha_heaviness_below2              | z_dr_x_heavy |         16 |      10 |      7 |           6 |           4 |   0.00116689  |      0.566433  | 0.094943  | 1.20721e-225 |
| future_var        | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |         16 |       6 |      3 |           3 |           3 |  -0.00237387  |     -0.380749  | 0.158398  | 2.53762e-26  |
| future_var        | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy |         16 |       7 |      7 |           3 |           4 |  -0.00311267  |     -0.234401  | 0.158398  | 7.18265e-79  |
| future_var        | interact_alpha_heaviness_inv                 | z_dq_x_heavy |         24 |      12 |      9 |           0 |          12 |  -0.00673461  |     -1.66042   | 0.207091  | 9.77321e-05  |
| future_var        | interact_alpha_heaviness_inv                 | z_dr_x_heavy |         24 |      13 |     10 |          12 |           1 |   0.00861128  |      1.61574   | 0.207091  | 0.000229858  |
| future_var        | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy |         24 |       9 |      7 |           0 |           9 |  -0.00743875  |     -1.16855   | 0.249287  | 1.62463e-12  |
| future_var        | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |         24 |       9 |      6 |           8 |           1 |   0.0105045   |      1.02634   | 0.249287  | 8.66003e-08  |
| future_var        | interact_alpha_heaviness_q25_below2          | z_dq_x_heavy |         24 |       6 |      4 |           3 |           3 |  -0.00462236  |     -0.415122  | 0.159453  | 1.7174e-06   |
| future_var        | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy |         24 |       8 |      5 |           1 |           7 |  -0.00854257  |     -0.847946  | 0.159453  | 0.000328002  |
| future_var        | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy |         24 |      11 |      8 |           8 |           3 |  -0.000579006 |     -0.107517  | 0.239731  | 1.57958e-24  |
| future_var        | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy |         24 |      10 |      7 |           1 |           9 |  -0.0241033   |     -1.36121   | 0.239731  | 1.69661e-14  |

## Note
This version uses assetwise nearest alpha matching. It is preferred when Stage 4 produces sparse per-security window_end dates.
