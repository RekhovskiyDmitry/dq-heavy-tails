# Stage 5: alpha-conditioned DQ vs DR memo

## Inputs
- Rolling metrics: `moex_stage2_alpha_windows_shares_parallel/02_stage2_rolling_metrics.csv`
- Tail alpha estimates: `moex_tail_stage4_main_shares_raw/stage4_tail_alpha_estimates_partial.csv`
- Max alpha alignment lag: 45 days
- Min alpha asset match ratio: 0.8

## Linked sample
| market   | period    |   window |   horizon |   tail_prob |   n |
|:---------|:----------|---------:|----------:|------------:|----:|
| shares   | full_2015 |      504 |        21 |       0.025 | 112 |
| shares   | full_2015 |      504 |        21 |       0.05  | 112 |
| shares   | full_2015 |      504 |        63 |       0.025 | 110 |
| shares   | full_2015 |      504 |        63 |       0.05  | 110 |
| shares   | full_2015 |      756 |        21 |       0.025 | 100 |
| shares   | full_2015 |      756 |        21 |       0.05  | 100 |
| shares   | full_2015 |      756 |        63 |       0.025 |  98 |
| shares   | full_2015 |      756 |        63 |       0.05  |  98 |
| shares   | full_2015 |     1008 |        21 |       0.025 |  88 |
| shares   | full_2015 |     1008 |        21 |       0.05  |  88 |
| shares   | full_2015 |     1008 |        63 |       0.025 |  86 |
| shares   | full_2015 |     1008 |        63 |       0.05  |  86 |

Alpha match ratio summary:
|       |   alpha_match_ratio |
|:------|--------------------:|
| count |                1188 |
| mean  |                   1 |
| std   |                   0 |
| min   |                   1 |
| 25%   |                   1 |
| 50%   |                   1 |
| 75%   |                   1 |
| max   |                   1 |

Portfolio alpha summary:
|                       |   count |        mean |         std |      min |      25% |      50% |         75% |        max |
|:----------------------|--------:|------------:|------------:|---------:|---------:|---------:|------------:|-----------:|
| alpha_median          |    1188 | 2.9195      | 0.74654     | 1.77239  | 2.18857  | 2.81641  | 3.54776     | 5.35089    |
| alpha_q25             |    1188 | 2.40717     | 0.449896    | 1.61839  | 1.99366  | 2.39043  | 2.76996     | 3.73301    |
| alpha_share_lt1_point |    1188 | 0           | 0           | 0        | 0        | 0        | 0           | 0          |
| alpha_share_gt2_point |    1188 | 0.835241    | 0.17706     | 0.266667 | 0.741667 | 0.925    | 0.958333    | 1          |
| p_alpha_lt_1_mean     |    1188 | 5.79198e-05 | 0.000214421 | 0        | 0        | 0        | 2.62605e-05 | 0.00259255 |
| p_alpha_gt_2_mean     |    1188 | 0.821298    | 0.143437    | 0.438344 | 0.696679 | 0.901203 | 0.932988    | 0.988657   |

## Regression reading guide
The key parameters are `z_dq_x_heavy` and `z_dr_x_heavy`. A positive and significant `z_dq_x_heavy`, especially when stronger than the DR interaction, supports the continuous-alpha version of the hypothesis: DQ becomes more informative as tails get heavier.

## Significant interaction coefficients at 10%
| market   | period    |   window |   horizon |   tail_prob | dependent         | spec                                         | param        |        coef |     t_hac |   pvalue_hac |        r2 |   n_obs |
|:---------|:----------|---------:|----------:|------------:|:------------------|:---------------------------------------------|:-------------|------------:|----------:|-------------:|----------:|--------:|
| shares   | full_2015 |      756 |        21 |       0.025 | future_es         | interact_alpha_heaviness_below2              | z_dq_x_heavy |  0.0106773  |   9.99936 | 1.53382e-23  | 0.0261414 |     100 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_es         | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.00498349 |  -9.07951 | 1.09065e-19  | 0.0261414 |     100 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_es         | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.00537019 |  -7.00618 | 2.44921e-12  | 0.046565  |     100 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_es         | interact_alpha_heaviness_below2              | z_dr_x_heavy |  0.00401763 |   6.14296 | 8.09986e-10  | 0.0383275 |     100 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_es         | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |  0.0100988  |   4.06095 | 4.88733e-05  | 0.046565  |     100 |
| shares   | full_2015 |      504 |        63 |       0.025 | future_es         | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.095585   |  -3.64961 | 0.000262636  | 0.0928718 |     110 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_es         | interact_alpha_heaviness_below2              | z_dq_x_heavy | -0.00339154 |  -3.64683 | 0.000265491  | 0.0383275 |     100 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_es         | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.06998    |  -3.37205 | 0.000746096  | 0.162737  |     110 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_es         | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy |  0.00467479 |   3.08292 | 0.0020498    | 0.0566884 |     100 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_es         | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy | -0.0634893  |  -2.90477 | 0.00367524   | 0.0550167 |      98 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_es         | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.0569908  |  -2.72302 | 0.0064689    | 0.175318  |     112 |
| shares   | full_2015 |      504 |        21 |       0.025 | future_es         | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.0703277  |  -2.49832 | 0.0124783    | 0.0954352 |     112 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_es         | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.0617261  |  -2.29916 | 0.0214958    | 0.0889661 |     112 |
| shares   | full_2015 |      504 |        63 |       0.025 | future_es         | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |  0.0359261  |   2.27952 | 0.022636     | 0.0928718 |     110 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_es         | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy | -0.029284   |  -2.2282  | 0.0258672    | 0.0989928 |      86 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_es         | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy | -0.044792   |  -2.18848 | 0.0286344    | 0.0414292 |     100 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_es         | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy | -0.0233279  |  -2.13007 | 0.0331661    | 0.105702  |      98 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_es         | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.112709   |  -2.10874 | 0.0349669    | 0.0972267 |      98 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_es         | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.0148069  |  -2.05801 | 0.0395895    | 0.204917  |     110 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_es         | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.0126979  |  -2.05343 | 0.0400309    | 0.103623  |     112 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_es         | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.0694853  |  -2.04215 | 0.041137     | 0.128441  |     110 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_es         | interact_alpha_heaviness_q25_below2          | z_dq_x_heavy | -0.0273251  |  -2.03918 | 0.041432     | 0.0792232 |      86 |
| shares   | full_2015 |     1008 |        21 |       0.05  | future_es         | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.00788629 |  -2.01976 | 0.0434086    | 0.0470042 |      88 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_es         | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.033191   |  -2.0168  | 0.0437162    | 0.278866  |      98 |
| shares   | full_2015 |      504 |        63 |       0.025 | future_es         | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.104047   |  -1.987   | 0.0469222    | 0.0754784 |     110 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_es         | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.0131594  |   1.98402 | 0.047254     | 0.0771784 |     100 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_es         | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy |  0.0488482  |   1.90238 | 0.0571209    | 0.0972267 |      98 |
| shares   | full_2015 |     1008 |        21 |       0.025 | future_es         | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.0216248  |   1.88236 | 0.0597876    | 0.0609883 |      88 |
| shares   | full_2015 |      504 |        21 |       0.025 | future_es         | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.073571   |  -1.86106 | 0.0627356    | 0.049519  |     112 |
| shares   | full_2015 |     1008 |        21 |       0.05  | future_es         | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.0109117  |  -1.86064 | 0.0627952    | 0.134165  |      88 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_es         | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |  0.0559929  |   1.85977 | 0.0629186    | 0.278866  |      98 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_es         | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.0128367  |   1.85492 | 0.0636071    | 0.103623  |     112 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_es         | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.0441565  |  -1.79496 | 0.0726602    | 0.154786  |     112 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_es         | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |  0.0823456  |   1.79236 | 0.0730751    | 0.308913  |      86 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_es         | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.0500844  |  -1.7769  | 0.0755844    | 0.168969  |     110 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_es         | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.123918   |  -1.76962 | 0.0767897    | 0.100819  |     100 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_es         | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.0319582  |  -1.75366 | 0.0794887    | 0.185064  |     100 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_es         | interact_alpha_heaviness_q25_below2          | z_dq_x_heavy |  0.0357997  |   1.74709 | 0.0806218    | 0.0550167 |      98 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_es         | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.0202803  |  -1.74338 | 0.0812679    | 0.167708  |      98 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_es         | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.0175861  |  -1.74268 | 0.0813898    | 0.0771784 |     100 |
| shares   | full_2015 |     1008 |        21 |       0.05  | future_es         | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |  0.0336432  |   1.74091 | 0.0816986    | 0.134165  |      88 |
| shares   | full_2015 |      504 |        63 |       0.025 | future_es         | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.0809128  |  -1.70693 | 0.0878356    | 0.0930878 |     110 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_es         | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.0118712  |   1.69489 | 0.0900956    | 0.167708  |      98 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_es         | interact_alpha_heaviness_below2              | z_dq_x_heavy |  0.0235719  |   1.68366 | 0.0922468    | 0.0889661 |     112 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_es         | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy |  0.0561378  |   1.67653 | 0.0936339    | 0.100819  |     100 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_es         | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy | -0.0313646  |  -1.67182 | 0.094559     | 0.11111   |     110 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_mdd        | interact_alpha_heaviness_below2              | z_dr_x_heavy |  0.0305522  |  17.4972  | 1.50373e-68  | 0.0596718 |     100 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_mdd        | interact_alpha_heaviness_below2              | z_dr_x_heavy |  0.0223398  |  15.2977  | 7.91636e-53  | 0.0610285 |     100 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_mdd        | interact_alpha_heaviness_below2              | z_dq_x_heavy | -0.0339939  | -13.4791  | 2.07694e-41  | 0.0610285 |     100 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_mdd        | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy |  0.0215656  |  12.5982  | 2.16143e-36  | 0.0677368 |     100 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_mdd        | interact_alpha_heaviness_below2              | z_dq_x_heavy | -0.0331769  | -12.0037  | 3.39645e-33  | 0.0596718 |     100 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_mdd        | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy |  0.0316921  |  10.4615  | 1.29762e-25  | 0.0683947 |     100 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_mdd        | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy | -0.0361178  |  -5.64927 | 1.61134e-08  | 0.0683947 |     100 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_mdd        | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy | -0.0315474  |  -5.44262 | 5.2504e-08   | 0.0677368 |     100 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_mdd        | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.426836   |  -4.46898 | 7.85917e-06  | 0.208866  |     110 |
| shares   | full_2015 |      504 |        63 |       0.025 | future_mdd        | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.375914   |  -4.07072 | 4.68688e-05  | 0.17142   |     110 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_mdd        | interact_alpha_heaviness_below2              | z_dr_x_heavy |  0.0166132  |   3.87302 | 0.000107493  | 0.0788016 |      98 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_mdd        | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.203486   |  -3.77395 | 0.000160686  | 0.199967  |     112 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_mdd        | interact_alpha_heaviness_below2              | z_dr_x_heavy |  0.0127     |   3.72325 | 0.000196672  | 0.0747909 |      98 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_mdd        | interact_alpha_heaviness_below2              | z_dq_x_heavy | -0.0172064  |  -3.39728 | 0.000680589  | 0.0747909 |      98 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_mdd        | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy |  0.0137204  |   3.37528 | 0.000737408  | 0.0805056 |      98 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_mdd        | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.182167   |  -3.15938 | 0.00158102   | 0.124766  |     112 |
| shares   | full_2015 |      504 |        63 |       0.025 | future_mdd        | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |  0.169461   |   3.10743 | 0.00188722   | 0.17142   |     110 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_mdd        | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.0612976  |  -3.02892 | 0.00245428   | 0.237461  |     110 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_mdd        | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy | -0.106549   |  -2.81369 | 0.00489766   | 0.0975169 |      86 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_mdd        | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.335553   |  -2.80146 | 0.00508712   | 0.167623  |     110 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_mdd        | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.18763    |   2.78101 | 0.005419     | 0.223629  |      86 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_mdd        | interact_alpha_heaviness_below2              | z_dq_x_heavy | -0.0156286  |  -2.65182 | 0.00800604   | 0.0788016 |      98 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_mdd        | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.0995882  |  -2.65158 | 0.00801156   | 0.219302  |      98 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_mdd        | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.0306671  |  -2.62278 | 0.00872151   | 0.121903  |     112 |
| shares   | full_2015 |     1008 |        21 |       0.025 | future_mdd        | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy | -0.0566395  |  -2.59304 | 0.00951328   | 0.0650182 |      88 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_mdd        | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy | -0.195959   |  -2.56857 | 0.010212     | 0.131823  |      98 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_mdd        | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.131856   |  -2.50517 | 0.0122393    | 0.259483  |      98 |
| shares   | full_2015 |     1008 |        21 |       0.05  | future_mdd        | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.0243869  |  -2.48644 | 0.0129028    | 0.0818632 |      88 |
| shares   | full_2015 |      504 |        21 |       0.025 | future_mdd        | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.186492   |  -2.47185 | 0.0134414    | 0.160003  |     112 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_mdd        | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.0701813  |   2.42931 | 0.0151277    | 0.219302  |      98 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_mdd        | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy |  0.0155245  |   2.40352 | 0.0162381    | 0.0830897 |      98 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_mdd        | interact_alpha_heaviness_below2              | z_dq_x_heavy |  0.0695424  |   2.33041 | 0.0197845    | 0.124766  |     112 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_mdd        | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |  0.149352   |   2.31973 | 0.0203555    | 0.208866  |     110 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_mdd        | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.231442   |  -2.31443 | 0.0206442    | 0.139444  |     100 |
| shares   | full_2015 |     1008 |        21 |       0.025 | future_mdd        | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.0748402  |  -2.29557 | 0.0217003    | 0.0785526 |      88 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_mdd        | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |  0.207259   |   2.21811 | 0.0265473    | 0.322177  |      86 |
| shares   | full_2015 |      504 |        63 |       0.025 | future_mdd        | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.281569   |  -2.16145 | 0.0306602    | 0.126561  |     110 |
| shares   | full_2015 |     1008 |        21 |       0.05  | future_mdd        | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.0283028  |  -2.08192 | 0.0373501    | 0.138605  |      88 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_mdd        | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.237735   |  -2.06624 | 0.0388059    | 0.166553  |     110 |
| shares   | full_2015 |     1008 |        21 |       0.025 | future_mdd        | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.0295733  |  -2.00117 | 0.0453738    | 0.08703   |      88 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_mdd        | interact_alpha_heaviness_below2              | z_dq_x_heavy |  0.128508   |   1.99874 | 0.0456362    | 0.167623  |     110 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_mdd        | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy |  0.115918   |   1.99815 | 0.0457002    | 0.139444  |     100 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_mdd        | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.264729   |  -1.95795 | 0.0502363    | 0.13626   |      98 |
| shares   | full_2015 |     1008 |        21 |       0.025 | future_mdd        | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.0466319  |   1.90536 | 0.0567327    | 0.08703   |      88 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_mdd        | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy | -0.0207907  |  -1.89827 | 0.0576612    | 0.0805056 |      98 |
| shares   | full_2015 |      504 |        21 |       0.025 | future_mdd        | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |  0.0787373  |   1.89706 | 0.0578196    | 0.160003  |     112 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_mdd        | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.0884662  |  -1.88059 | 0.0600274    | 0.132564  |      86 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_mdd        | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy | -0.0845555  |  -1.87479 | 0.0608221    | 0.131147  |      98 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_mdd        | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.0380029  |  -1.8742  | 0.0609023    | 0.0947796 |     100 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_mdd        | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.0295503  |   1.86924 | 0.0615899    | 0.121903  |     112 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_mdd        | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.0679963  |  -1.85013 | 0.0642949    | 0.240155  |     110 |
| shares   | full_2015 |      504 |        21 |       0.025 | future_mdd        | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.153669   |  -1.805   | 0.0710748    | 0.101592  |     112 |
| shares   | full_2015 |     1008 |        21 |       0.025 | future_mdd        | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.039621   |  -1.77768 | 0.075456     | 0.101518  |      88 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_mdd        | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |  0.174441   |   1.77448 | 0.0759846    | 0.259483  |      98 |
| shares   | full_2015 |     1008 |        21 |       0.05  | future_mdd        | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |  0.0655703  |   1.74352 | 0.0812421    | 0.138605  |      88 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_mdd        | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.156346   |  -1.73916 | 0.0820064    | 0.223629  |      86 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_mdd        | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.119831   |  -1.73068 | 0.0835093    | 0.141277  |     112 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_mdd        | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy | -0.0843856  |  -1.71597 | 0.0861679    | 0.08184   |     100 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_mdd        | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.0261992  |   1.71187 | 0.08692      | 0.0947796 |     100 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_mdd        | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.0280128  |  -1.68817 | 0.0913782    | 0.122284  |     112 |
| shares   | full_2015 |     1008 |        63 |       0.05  | future_mdd        | interact_alpha_heaviness_q25_below2          | z_dq_x_heavy | -0.125229   |  -1.6475  | 0.099456     | 0.107975  |      86 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_rv_ann     | interact_alpha_heaviness_below2              | z_dq_x_heavy |  0.139898   |  24.6753  | 1.9707e-134  | 0.0924577 |     100 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.101727   | -23.6558  | 1.0277e-123  | 0.0917175 |     100 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_below2              | z_dq_x_heavy |  0.14333    |  23.1881  | 6.00238e-119 | 0.0917175 |     100 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_rv_ann     | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.0722362  | -23.0932  | 5.41962e-118 | 0.0924577 |     100 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_rv_ann     | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.0742039  | -20.2736  | 2.19777e-91  | 0.101738  |     100 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_rv_ann     | interact_alpha_heaviness_below2              | z_dq_x_heavy |  0.0680477  |  11.21    | 3.64082e-29  | 0.0910868 |      98 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_rv_ann     | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |  0.143266   |  11.137   | 8.28449e-29  | 0.101738  |     100 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_rv_ann     | interact_alpha_heaviness_below2              | z_dq_x_heavy |  0.0709874  |  10.4972  | 8.89778e-26  | 0.0900898 |      98 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.0971901  | -10.2502  | 1.1811e-24   | 0.108166  |     100 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_rv_ann     | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.0453496  |  -7.81457 | 5.51524e-15  | 0.0900898 |      98 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_rv_ann     | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.0318344  |  -7.79406 | 6.48918e-15  | 0.0910868 |      98 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_rv_ann     | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.030927   |  -7.16569 | 7.73976e-13  | 0.100189  |      98 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |  0.132177   |   6.37404 | 1.84109e-10  | 0.108166  |     100 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_rv_ann     | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.0444124  |  -4.40085 | 1.07829e-05  | 0.106294  |      98 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_rv_ann     | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |  0.0578436  |   3.79139 | 0.000149808  | 0.100189  |      98 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_rv_ann     | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy | -0.26728    |  -3.59096 | 0.000329466  | 0.127018  |      98 |
| shares   | full_2015 |      504 |        63 |       0.025 | future_rv_ann     | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.320342   |  -2.9025  | 0.003702     | 0.142123  |     110 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.369723   |  -2.79214 | 0.00523612   | 0.211402  |     112 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_rv_ann     | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.088571   |   2.6239  | 0.008693     | 0.199696  |      98 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_rv_ann     | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |  0.0588795  |   2.58745 | 0.00966884   | 0.106294  |      98 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_rv_ann     | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy | -0.256019   |  -2.50607 | 0.0122083    | 0.115084  |     100 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_rv_ann     | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |  0.363781   |   2.41721 | 0.0156399    | 0.347442  |      86 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_rv_ann     | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.294733   |  -2.36866 | 0.0178526    | 0.188     |     110 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.361188   |  -2.3592  | 0.0183142    | 0.202682  |     112 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.0884489  |   2.34892 | 0.0188281    | 0.1248    |     100 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_rv_ann     | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.443758   |  -2.299   | 0.0215049    | 0.150689  |      98 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.357726   |  -2.22785 | 0.0258905    | 0.163161  |     100 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_rv_ann     | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.210016   |  -2.20571 | 0.0274042    | 0.328266  |      98 |
| shares   | full_2015 |      504 |        63 |       0.025 | future_rv_ann     | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |  0.140824   |   2.15504 | 0.0311587    | 0.142123  |     110 |
| shares   | full_2015 |      504 |        21 |       0.025 | future_rv_ann     | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.298778   |  -2.15461 | 0.0311923    | 0.152732  |     112 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_rv_ann     | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.614341   |  -2.12056 | 0.0339586    | 0.164413  |     100 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_rv_ann     | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.137099   |  -2.1034  | 0.0354312    | 0.199696  |      98 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_rv_ann     | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy |  0.201522   |   2.08149 | 0.0373893    | 0.150689  |      98 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.0868888  |   2.0573  | 0.0396578    | 0.144266  |     112 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_rv_ann     | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.0885493  |  -2.04912 | 0.0404503    | 0.231103  |     110 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.341629   |  -2.01234 | 0.0441844    | 0.130866  |     112 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_rv_ann     | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy |  0.310476   |   1.9823  | 0.0474454    | 0.164413  |     100 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_below2              | z_dq_x_heavy |  0.182049   |   1.97984 | 0.0477214    | 0.130866  |     112 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy | -0.240557   |  -1.97094 | 0.0487309    | 0.114757  |     100 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_rv_ann     | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |  0.355536   |   1.96552 | 0.0493542    | 0.328266  |      98 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.114172   |  -1.9549  | 0.0505949    | 0.1248    |     100 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.204065   |  -1.89075 | 0.0586574    | 0.233827  |     100 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.0684704  |  -1.8863  | 0.059254     | 0.144266  |     112 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_rv_ann     | interact_alpha_heaviness_q25_below2          | z_dq_x_heavy |  0.142799   |   1.86997 | 0.0614883    | 0.127018  |      98 |
| shares   | full_2015 |     1008 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.042365   |  -1.79825 | 0.072137     | 0.0711153 |      88 |
| shares   | full_2015 |     1008 |        21 |       0.025 | future_rv_ann     | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.110991   |   1.78312 | 0.0745661    | 0.0952012 |      88 |
| shares   | full_2015 |     1008 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |  0.20446    |   1.77992 | 0.0750898    | 0.161617  |      88 |
| shares   | full_2015 |      504 |        21 |       0.025 | future_rv_ann     | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |  0.147316   |   1.74708 | 0.0806226    | 0.152732  |     112 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_q25_below2          | z_dq_x_heavy |  0.106426   |   1.73302 | 0.0830913    | 0.114758  |     112 |
| shares   | full_2015 |     1008 |        21 |       0.025 | future_rv_ann     | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.180004   |  -1.72774 | 0.084034     | 0.0935773 |      88 |
| shares   | full_2015 |     1008 |        21 |       0.025 | future_rv_ann     | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.108252   |  -1.72763 | 0.0840547    | 0.14361   |      88 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_rv_ann     | interact_alpha_heaviness_q25_below2          | z_dq_x_heavy |  0.162248   |   1.72375 | 0.0847531    | 0.115084  |     100 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy |  0.158856   |   1.65497 | 0.0979301    | 0.202682  |     112 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_rv_ann     | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |  0.3882     |   1.65305 | 0.0983198    | 0.233827  |     100 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_tail_event | interact_alpha_heaviness_below2              | z_dr_x_heavy |  0.0883322  |   4.23525 | 2.28297e-05  | 0.0770834 |      98 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_tail_event | interact_alpha_heaviness_below2              | z_dr_x_heavy |  0.0953642  |   4.17177 | 3.02247e-05  | 0.179895  |      98 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_tail_event | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy |  0.0962149  |   3.63076 | 0.000282592  | 0.0956754 |      98 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_tail_event | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy |  0.0930626  |   3.55052 | 0.000384474  | 0.2017    |      98 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_tail_event | interact_alpha_heaviness_below2              | z_dr_x_heavy |  0.0653257  |   3.33016 | 0.000867956  | 0.0782096 |     100 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_tail_event | interact_alpha_heaviness_below2              | z_dr_x_heavy |  0.0432777  |   3.07135 | 0.00213094   | 0.0795942 |     100 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_tail_event | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.215584   |  -2.87569 | 0.0040314    | 0.24207   |     110 |
| shares   | full_2015 |     1008 |        21 |       0.025 | future_tail_event | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy | -0.747726   |  -2.83322 | 0.00460814   | 0.108432  |      88 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_tail_event | interact_alpha_heaviness_below2              | z_dr_x_heavy | -1.12541    |  -2.79288 | 0.00522404   | 0.22619   |     110 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_tail_event | interact_alpha_heaviness_below2              | z_dq_x_heavy |  0.553464   |   2.65015 | 0.00804563   | 0.22619   |     110 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_tail_event | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy |  0.0480221  |   2.62951 | 0.00855087   | 0.115736  |     100 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_tail_event | interact_alpha_heaviness_below2              | z_dr_x_heavy | -1.80023    |  -2.62878 | 0.00856913   | 0.154491  |     112 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_tail_event | interact_alpha_heaviness_below2              | z_dq_x_heavy |  0.879015   |   2.57529 | 0.0100157    | 0.154491  |     112 |
| shares   | full_2015 |     1008 |        21 |       0.025 | future_tail_event | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.80623    |  -2.56461 | 0.0103291    | 0.219403  |      88 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_tail_event | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -1.09576    |  -2.5507  | 0.0107508    | 0.2603    |     110 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_tail_event | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy | -1.06667    |  -2.44976 | 0.0142951    | 0.105741  |     100 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_tail_event | interact_alpha_heaviness_below2              | z_dq_x_heavy |  0.0542139  |   2.41079 | 0.0159181    | 0.0795942 |     100 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_tail_event | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -1.21126    |  -2.32296 | 0.0201812    | 0.261182  |     110 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_tail_event | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.724787   |  -2.30238 | 0.0213137    | 0.33099   |      86 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_tail_event | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.784441   |  -2.2979  | 0.0215677    | 0.440992  |      86 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_tail_event | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.193269   |   2.1527  | 0.0313422    | 0.24207   |     110 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_tail_event | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy |  0.0537282  |   2.08663 | 0.0369216    | 0.11719   |     100 |
| shares   | full_2015 |      504 |        63 |       0.025 | future_tail_event | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -1.44893    |  -2.03896 | 0.0414542    | 0.207089  |     110 |
| shares   | full_2015 |      504 |        63 |       0.025 | future_tail_event | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.360443   |   2.03282 | 0.0420704    | 0.209086  |     110 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_tail_event | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy |  0.482507   |   1.97599 | 0.0481554    | 0.2603    |     110 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_tail_event | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -1.51476    |  -1.96452 | 0.0494702    | 0.170281  |     112 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_tail_event | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.202542   |  -1.90189 | 0.0571859    | 0.141321  |     112 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_tail_event | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.660851   |   1.89235 | 0.058445     | 0.428342  |      86 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_tail_event | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -1.18155    |  -1.86494 | 0.0621905    | 0.163444  |     112 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_tail_event | interact_alpha_heaviness_below2              | z_dq_x_heavy | -0.0466406  |  -1.84089 | 0.0656376    | 0.179895  |      98 |
| shares   | full_2015 |     1008 |        21 |       0.05  | future_tail_event | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy | -0.561281   |  -1.81271 | 0.0698772    | 0.218428  |      88 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_tail_event | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.682669   |  -1.8077  | 0.0706533    | 0.428342  |      86 |
| shares   | full_2015 |      504 |        63 |       0.025 | future_tail_event | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy |  0.738512   |   1.78913 | 0.0735934    | 0.207089  |     110 |
| shares   | full_2015 |     1008 |        21 |       0.05  | future_tail_event | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.521313   |  -1.75008 | 0.080105     | 0.231889  |      88 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_tail_event | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.239458   |  -1.73146 | 0.0833705    | 0.244428  |     110 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_tail_event | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.312486   |  -1.72693 | 0.0841807    | 0.245277  |      98 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_tail_event | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy | -0.356366   |  -1.68476 | 0.092034     | 0.165147  |      98 |
| shares   | full_2015 |     1008 |        21 |       0.05  | future_tail_event | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.182976   |  -1.66427 | 0.0960575    | 0.223668  |      88 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_tail_event | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |  0.477987   |   1.65782 | 0.0973539    | 0.261182  |     110 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_var        | interact_alpha_heaviness_below2              | z_dr_x_heavy |  0.0149365  |  32.0686  | 1.20721e-225 | 0.0880571 |     100 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_var        | interact_alpha_heaviness_below2              | z_dq_x_heavy | -0.0176962  | -22.958   | 1.22709e-116 | 0.0880571 |     100 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_var        | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy |  0.0152103  |  18.8027  | 7.18265e-79  | 0.0942302 |     100 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_var        | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy | -0.0182805  | -10.615   | 2.53762e-26  | 0.0942302 |     100 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_var        | interact_alpha_heaviness_below2              | z_dr_x_heavy |  0.0029312  |   6.4853  | 8.85547e-11  | 0.04021   |     100 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_var        | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.0573226  |  -5.04114 | 4.62773e-07  | 0.298013  |     110 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_var        | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy |  0.00266373 |   4.62738 | 3.70315e-06  | 0.0533455 |     100 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_var        | interact_alpha_heaviness_below2              | z_dq_x_heavy | -0.00360312 |  -4.16601 | 3.0997e-05   | 0.04021   |     100 |
| shares   | full_2015 |      504 |        63 |       0.025 | future_var        | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.063221   |  -4.12621 | 3.68785e-05  | 0.23688   |     110 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_var        | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy | -0.0486852  |  -3.54215 | 0.000396874  | 0.212426  |      98 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_var        | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.007879   |  -3.53732 | 0.000404203  | 0.367478  |     110 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_var        | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.0298873  |   2.99908 | 0.00270794   | 0.256105  |      86 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_var        | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.0447738  |  -2.90805 | 0.00363692   | 0.242509  |     112 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_var        | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.0417108  |  -2.89548 | 0.00378577   | 0.245986  |     110 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_var        | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.0098115  |  -2.85629 | 0.0042862    | 0.189284  |     112 |
| shares   | full_2015 |      504 |        63 |       0.025 | future_var        | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |  0.0246164  |   2.83537 | 0.00457731   | 0.23688   |     110 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_var        | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.043161   |  -2.73145 | 0.00630571   | 0.270975  |     110 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_var        | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.0625649  |  -2.70369 | 0.00685749   | 0.217823  |      98 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_var        | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.0423196  |  -2.70279 | 0.00687607   | 0.152059  |     112 |
| shares   | full_2015 |      504 |        21 |       0.025 | future_var        | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy | -0.0625491  |  -2.64806 | 0.00809562   | 0.123323  |     112 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_var        | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.0143526  |  -2.61907 | 0.00881695   | 0.303953  |      98 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_var        | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |  0.0202139  |   2.58907 | 0.00962363   | 0.298013  |     110 |
| shares   | full_2015 |     1008 |        21 |       0.05  | future_var        | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.00892078 |  -2.40371 | 0.0162297    | 0.16699   |      88 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_var        | interact_alpha_heaviness_below2_controls     | z_dr_x_heavy |  0.0018988  |   2.38051 | 0.0172887    | 0.155037  |      98 |
| shares   | full_2015 |     1008 |        21 |       0.05  | future_var        | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.00635794 |  -2.35201 | 0.0186721    | 0.0881729 |      88 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_var        | interact_alpha_heaviness_below2              | z_dr_x_heavy |  0.00147376 |   2.31783 | 0.0204584    | 0.13099   |      98 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_var        | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.0103277  |  -2.31279 | 0.0207344    | 0.285     |      98 |
| shares   | full_2015 |     1008 |        21 |       0.05  | future_var        | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |  0.0235413  |   2.25045 | 0.0244202    | 0.16699   |      88 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_var        | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.00941392 |  -2.22684 | 0.0259577    | 0.190953  |     112 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_var        | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.00843908 |   2.15807 | 0.0309226    | 0.285     |      98 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_var        | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.00935742 |   2.15119 | 0.0314611    | 0.189284  |     112 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_var        | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.0125195  |  -2.14868 | 0.0316599    | 0.139353  |     100 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_var        | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy | -0.0339135  |  -2.14281 | 0.0321286    | 0.0622647 |     100 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_var        | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy |  0.0332268  |   2.111   | 0.0347725    | 0.217823  |      98 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_var        | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.00972661 |   2.1042  | 0.0353607    | 0.139353  |     100 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_var        | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy | -0.0205973  |  -2.07947 | 0.0375743    | 0.209214  |     110 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_var        | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy | -0.0186871  |  -2.06316 | 0.0390976    | 0.171999  |      86 |
| shares   | full_2015 |     1008 |        21 |       0.025 | future_var        | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.0182664  |   2.05953 | 0.0394433    | 0.07623   |      88 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_var        | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |  0.0324049  |   2.05194 | 0.0401755    | 0.377318  |      86 |
| shares   | full_2015 |      756 |        63 |       0.025 | future_var        | interact_alpha_heaviness_q25_below2          | z_dq_x_heavy |  0.026643   |   2.01217 | 0.0442024    | 0.212426  |      98 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_var        | interact_alpha_heaviness_below2              | z_dq_x_heavy |  0.0154239  |   2.00873 | 0.0445657    | 0.245986  |     110 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_var        | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.0106309  |  -1.9922  | 0.0463489    | 0.37314   |     110 |
| shares   | full_2015 |      756 |        63 |       0.05  | future_var        | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |  0.0185911  |   1.95936 | 0.0500707    | 0.303953  |      98 |
| shares   | full_2015 |      504 |        63 |       0.025 | future_var        | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.047525   |  -1.94205 | 0.0521308    | 0.196907  |     110 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_var        | interact_alpha_heaviness_q25_below2_controls | z_dr_x_heavy | -0.0903741  |  -1.94016 | 0.0523603    | 0.117223  |     100 |
| shares   | full_2015 |      504 |        63 |       0.05  | future_var        | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy |  0.0148402  |   1.92947 | 0.0536724    | 0.270975  |     110 |
| shares   | full_2015 |      504 |        21 |       0.025 | future_var        | interact_alpha_heaviness_below2              | z_dr_x_heavy | -0.0587106  |  -1.90775 | 0.0564234    | 0.0720385 |     112 |
| shares   | full_2015 |      756 |        21 |       0.05  | future_var        | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.0175249  |  -1.90219 | 0.0571467    | 0.187499  |     100 |
| shares   | full_2015 |     1008 |        21 |       0.025 | future_var        | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.0123543  |  -1.8478  | 0.064631     | 0.07623   |      88 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_var        | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy | -0.00359819 |  -1.81909 | 0.0688971    | 0.0533455 |     100 |
| shares   | full_2015 |      504 |        21 |       0.025 | future_var        | interact_alpha_heaviness_below2_controls     | z_dq_x_heavy |  0.0250357  |   1.81391 | 0.0696911    | 0.123323  |     112 |
| shares   | full_2015 |      756 |        21 |       0.025 | future_var        | interact_alpha_heaviness_q25_below2_controls | z_dq_x_heavy |  0.041159   |   1.79112 | 0.0732735    | 0.117223  |     100 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_var        | interact_alpha_heaviness_q25_below2          | z_dq_x_heavy | -0.0168054  |  -1.78479 | 0.0742951    | 0.133566  |      86 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_var        | interact_alpha_heaviness_inv                 | z_dq_x_heavy | -0.0250667  |  -1.71725 | 0.0859339    | 0.256105  |      86 |
| shares   | full_2015 |     1008 |        63 |       0.025 | future_var        | interact_alpha_heaviness_q25_below2          | z_dr_x_heavy | -0.0158366  |  -1.69392 | 0.0902806    | 0.133566  |      86 |
| shares   | full_2015 |     1008 |        21 |       0.05  | future_var        | interact_alpha_heaviness_inv                 | z_dr_x_heavy |  0.00446475 |   1.67195 | 0.0945346    | 0.0881729 |      88 |
| shares   | full_2015 |     1008 |        21 |       0.025 | future_var        | interact_alpha_heaviness_inv_controls        | z_dq_x_heavy | -0.0186664  |  -1.66814 | 0.0952887    | 0.114051  |      88 |
| shares   | full_2015 |      504 |        21 |       0.05  | future_var        | interact_alpha_heaviness_inv_controls        | z_dr_x_heavy |  0.0111904  |   1.64737 | 0.0994811    | 0.190953  |     112 |

## Files
- `01_alpha_linked_rolling_metrics.csv`
- `02_alpha_interaction_regressions.csv`
- `03_alpha_bin_summary.csv`
- `04_alpha_signal_correlations.csv`