#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stage 5: Tail-index-conditioned DQ vs DR tests.

Purpose
-------
Merge portfolio-level rolling DQ/DR metrics with asset-level rolling tail-index estimates,
then test whether the relative usefulness of DQ vs DR changes with tail heaviness.

Inputs
------
1) Stage 2 rolling metrics, e.g. moex_stage2_outputs/02_stage2_rolling_metrics.csv
2) Stage 4 tail alpha estimates, e.g. moex_tail_stage4_full/03_tail_alpha_estimates.csv
   or parquet.

Main outputs
------------
- 01_alpha_linked_rolling_metrics.csv
- 02_alpha_interaction_regressions.csv
- 03_alpha_bin_summary.csv
- 04_alpha_signal_correlations.csv
- research_stage5_alpha_interactions_memo.md

Notes
-----
This is deliberately a research script, not a black box. Inspect the generated memo and CSVs.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

try:
    import statsmodels.api as sm
except ImportError as exc:
    raise SystemExit("Please install statsmodels: pip install statsmodels") from exc


DEPENDENTS_DEFAULT = [
    "future_tail_event",
    "future_es",
    "future_var",
    "future_rv_ann",
    "future_mdd",
]

BASE_SIGNALS = ["dq_es", "dr_es_concentration"]
BASE_CONTROLS = ["current_es", "current_rv_ann"]


def read_table(path: str) -> pd.DataFrame:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(path)
    if p.suffix.lower() in {".parquet", ".pq"}:
        return pd.read_parquet(p)
    return pd.read_csv(p)


def parse_assets(x) -> List[str]:
    if pd.isna(x):
        return []
    if isinstance(x, list):
        return [str(a).strip() for a in x if str(a).strip()]
    return [a.strip() for a in str(x).split(",") if a.strip()]


def zscore(s: pd.Series) -> pd.Series:
    s = pd.to_numeric(s, errors="coerce")
    mu = s.mean(skipna=True)
    sd = s.std(skipna=True, ddof=0)
    if not np.isfinite(sd) or sd == 0:
        return s * np.nan
    return (s - mu) / sd


def safe_mean(x: pd.Series) -> float:
    x = pd.to_numeric(x, errors="coerce")
    return float(x.mean()) if x.notna().any() else np.nan


def safe_quantile(x: pd.Series, q: float) -> float:
    x = pd.to_numeric(x, errors="coerce").dropna()
    return float(x.quantile(q)) if len(x) else np.nan


def build_alpha_lookup(alpha: pd.DataFrame) -> Tuple[Dict[Tuple[str, int], List[pd.Timestamp]], Dict[Tuple[str, int, pd.Timestamp], pd.DataFrame]]:
    required = {"market", "secid", "window", "window_end", "alpha_consensus"}
    missing = required - set(alpha.columns)
    if missing:
        raise ValueError(f"alpha estimates missing columns: {sorted(missing)}")
    a = alpha.copy()
    a["window_end"] = pd.to_datetime(a["window_end"])
    a["window"] = a["window"].astype(int)
    lookup: Dict[Tuple[str, int, pd.Timestamp], pd.DataFrame] = {}
    dates: Dict[Tuple[str, int], List[pd.Timestamp]] = {}
    for (market, window, dt), g in a.groupby(["market", "window", "window_end"], sort=True):
        key = (str(market), int(window), pd.Timestamp(dt))
        # If duplicate secid accidentally exists, keep last.
        lookup[key] = g.drop_duplicates("secid", keep="last").set_index("secid")
    for market, window in a[["market", "window"]].drop_duplicates().itertuples(index=False):
        ds = sorted(a.loc[(a["market"] == market) & (a["window"] == window), "window_end"].dropna().unique())
        dates[(str(market), int(window))] = [pd.Timestamp(d) for d in ds]
    return dates, lookup


def nearest_alpha_date(dates: List[pd.Timestamp], target: pd.Timestamp, max_lag_days: int) -> Optional[pd.Timestamp]:
    if not dates:
        return None
    # Latest alpha window ending at or before target.
    lo, hi = 0, len(dates)
    while lo < hi:
        mid = (lo + hi) // 2
        if dates[mid] <= target:
            lo = mid + 1
        else:
            hi = mid
    idx = lo - 1
    if idx < 0:
        return None
    dt = dates[idx]
    if (target - dt).days > max_lag_days:
        return None
    return dt


def aggregate_alpha_for_portfolio(
    assets: List[str],
    alpha_df: pd.DataFrame,
) -> dict:
    if not assets or alpha_df is None or alpha_df.empty:
        return {}
    avail = [a for a in assets if a in alpha_df.index]
    g = alpha_df.loc[avail].copy() if avail else pd.DataFrame()
    if g.empty:
        return {
            "alpha_n_assets_matched": 0,
            "alpha_match_ratio": 0.0,
        }
    alpha = pd.to_numeric(g.get("alpha_consensus"), errors="coerce")
    out = {
        "alpha_n_assets_matched": int(alpha.notna().sum()),
        "alpha_match_ratio": float(alpha.notna().sum() / max(1, len(assets))),
        "alpha_mean": safe_mean(alpha),
        "alpha_median": safe_quantile(alpha, 0.50),
        "alpha_q10": safe_quantile(alpha, 0.10),
        "alpha_q25": safe_quantile(alpha, 0.25),
        "alpha_min": float(alpha.min()) if alpha.notna().any() else np.nan,
        "alpha_share_lt1_point": float((alpha < 1.0).mean()) if alpha.notna().any() else np.nan,
        "alpha_share_1_2_point": float(((alpha >= 1.0) & (alpha <= 2.0)).mean()) if alpha.notna().any() else np.nan,
        "alpha_share_gt2_point": float((alpha > 2.0).mean()) if alpha.notna().any() else np.nan,
    }
    for col in ["p_alpha_lt_1", "p_alpha_gt_2", "theta_runs", "zero_share_window", "max_loss_window"]:
        if col in g.columns:
            out[f"{col}_mean"] = safe_mean(g[col])
            out[f"{col}_median"] = safe_quantile(g[col], 0.50)
    if "tail_group" in g.columns:
        tg = g["tail_group"].astype(str)
        denom = len(tg)
        for name in [
            "strict_alpha_lt_1",
            "strict_alpha_1_2",
            "strict_alpha_gt_2",
            "point_alpha_1_2_uncertain",
            "point_alpha_gt_2_uncertain",
        ]:
            out[f"share_{name}"] = float((tg == name).sum() / denom) if denom else np.nan
    return out


def link_alpha_to_rolling(
    rolling: pd.DataFrame,
    alpha: pd.DataFrame,
    max_align_days: int = 45,
    min_match_ratio: float = 0.5,
) -> pd.DataFrame:
    r = rolling.copy()
    r["tradedate"] = pd.to_datetime(r["tradedate"])
    if "assets" not in r.columns:
        raise ValueError("rolling metrics must include an 'assets' column with comma-separated secids")
    dates, lookup = build_alpha_lookup(alpha)
    rows = []
    cache = {}
    for idx, row in r.iterrows():
        market = str(row["market"])
        window = int(row["window"])
        target = pd.Timestamp(row["tradedate"])
        asset_str = row["assets"]
        ckey = (market, window, target, asset_str)
        if ckey in cache:
            agg = cache[ckey]
        else:
            dt = nearest_alpha_date(dates.get((market, window), []), target, max_lag_days=max_align_days)
            if dt is None:
                agg = {
                    "alpha_window_end": pd.NaT,
                    "alpha_lag_days": np.nan,
                    "alpha_n_assets_matched": 0,
                    "alpha_match_ratio": 0.0,
                }
            else:
                adf = lookup[(market, window, dt)]
                assets = parse_assets(asset_str)
                agg = aggregate_alpha_for_portfolio(assets, adf)
                agg["alpha_window_end"] = dt
                agg["alpha_lag_days"] = (target - dt).days
            cache[ckey] = agg
        rows.append(agg)
    out = pd.concat([r.reset_index(drop=True), pd.DataFrame(rows)], axis=1)
    out = out[out["alpha_match_ratio"].fillna(0) >= min_match_ratio].copy()
    # Tail-heaviness transforms: higher means heavier tail.
    out["alpha_heaviness_inv"] = 1.0 / out["alpha_median"].replace(0, np.nan)
    out["alpha_heaviness_below2"] = np.maximum(0.0, 2.0 - out["alpha_median"])
    out["alpha_heaviness_q25_below2"] = np.maximum(0.0, 2.0 - out["alpha_q25"])
    out["alpha_lightness_above2"] = np.maximum(0.0, out["alpha_median"] - 2.0)
    return out


def run_hac_ols(df: pd.DataFrame, y: str, xvars: List[str], horizon: int) -> Tuple[Optional[object], Optional[pd.DataFrame], str]:
    cols = [y] + xvars
    d = df[cols].replace([np.inf, -np.inf], np.nan).dropna()
    if len(d) < max(30, len(xvars) + 10):
        return None, None, "too_few_obs"
    X = sm.add_constant(d[xvars], has_constant="add")
    yv = pd.to_numeric(d[y], errors="coerce")
    try:
        model = sm.OLS(yv, X).fit(cov_type="HAC", cov_kwds={"maxlags": max(1, int(math.ceil(horizon / 21)))})
    except Exception as e:
        return None, None, f"fit_error: {e}"
    tab = pd.DataFrame({
        "param": model.params.index,
        "coef": model.params.values,
        "std_err_hac": model.bse.values,
        "t_hac": model.tvalues.values,
        "pvalue_hac": model.pvalues.values,
    })
    return model, tab, "ok"


def prepare_regression_frame(g: pd.DataFrame, heaviness: str, controls: bool) -> Tuple[pd.DataFrame, List[str]]:
    d = g.copy()
    raw_vars = ["dq_es", "dr_es_concentration", heaviness]
    if controls:
        raw_vars += [c for c in BASE_CONTROLS if c in d.columns]
    if "p_alpha_lt_1_mean" in d.columns:
        raw_vars += ["p_alpha_lt_1_mean"]
    # Z-score only columns that exist.
    xvars = []
    for col in raw_vars:
        if col in d.columns:
            z = f"z_{col}"
            d[z] = zscore(d[col])
            xvars.append(z)
    # Required interactions.
    if f"z_{heaviness}" in d.columns:
        d["z_dq_x_heavy"] = d["z_dq_es"] * d[f"z_{heaviness}"]
        d["z_dr_x_heavy"] = d["z_dr_es_concentration"] * d[f"z_{heaviness}"]
        xvars += ["z_dq_x_heavy", "z_dr_x_heavy"]
    return d, xvars


def regression_suite(
    linked: pd.DataFrame,
    dependents: List[str],
    min_n: int = 50,
    heaviness_vars: Optional[List[str]] = None,
) -> pd.DataFrame:
    if heaviness_vars is None:
        heaviness_vars = ["alpha_heaviness_inv", "alpha_heaviness_below2", "alpha_heaviness_q25_below2"]
    results = []
    group_cols = ["market", "period", "window", "horizon", "tail_prob"]
    for keys, g in linked.groupby(group_cols, dropna=False):
        market, period, window, horizon, tail_prob = keys
        if len(g) < min_n:
            continue
        for y in dependents:
            if y not in g.columns:
                continue
            for heaviness in heaviness_vars:
                if heaviness not in g.columns:
                    continue
                for controls in [False, True]:
                    spec = f"interact_{heaviness}" + ("_controls" if controls else "")
                    d, xvars = prepare_regression_frame(g, heaviness=heaviness, controls=controls)
                    model, tab, status = run_hac_ols(d, y, xvars, int(horizon))
                    if status != "ok":
                        results.append({
                            "market": market, "period": period, "window": window, "horizon": horizon,
                            "tail_prob": tail_prob, "dependent": y, "spec": spec, "status": status,
                            "n_obs": len(d), "param": None,
                        })
                        continue
                    nobs = int(model.nobs)
                    for _, rr in tab.iterrows():
                        results.append({
                            "market": market, "period": period, "window": window, "horizon": horizon,
                            "tail_prob": tail_prob, "dependent": y, "spec": spec, "status": "ok",
                            "n_obs": nobs, "r2": float(model.rsquared), "adj_r2": float(model.rsquared_adj),
                            "aic": float(model.aic), "bic": float(model.bic),
                            "param": rr["param"], "coef": rr["coef"], "std_err_hac": rr["std_err_hac"],
                            "t_hac": rr["t_hac"], "pvalue_hac": rr["pvalue_hac"],
                        })
    return pd.DataFrame(results)


def bin_summary(linked: pd.DataFrame, n_bins: int = 4) -> pd.DataFrame:
    rows = []
    group_cols = ["market", "period", "window", "horizon", "tail_prob"]
    for keys, g in linked.groupby(group_cols, dropna=False):
        if g["alpha_median"].notna().sum() < n_bins * 5:
            continue
        try:
            bins = pd.qcut(g["alpha_median"], q=n_bins, duplicates="drop")
        except Exception:
            continue
        d = g.copy()
        d["alpha_bin"] = bins.astype(str)
        for b, bg in d.groupby("alpha_bin"):
            rec = dict(zip(group_cols, keys))
            rec.update({
                "alpha_bin": b,
                "n_obs": len(bg),
                "alpha_median_mean": safe_mean(bg["alpha_median"]),
                "alpha_q25_mean": safe_mean(bg["alpha_q25"]),
                "dq_es_mean": safe_mean(bg["dq_es"]),
                "dr_es_concentration_mean": safe_mean(bg["dr_es_concentration"]),
                "future_tail_event_mean": safe_mean(bg["future_tail_event"]) if "future_tail_event" in bg else np.nan,
                "future_es_mean": safe_mean(bg["future_es"]) if "future_es" in bg else np.nan,
                "future_mdd_mean": safe_mean(bg["future_mdd"]) if "future_mdd" in bg else np.nan,
            })
            rows.append(rec)
    return pd.DataFrame(rows)


def correlation_summary(linked: pd.DataFrame) -> pd.DataFrame:
    vars_ = [
        "dq_es", "dr_es_concentration", "current_es", "current_rv_ann",
        "alpha_median", "alpha_q25", "alpha_heaviness_inv", "alpha_heaviness_below2",
        "p_alpha_lt_1_mean", "p_alpha_gt_2_mean",
        "future_tail_event", "future_es", "future_mdd", "future_rv_ann",
    ]
    vars_ = [v for v in vars_ if v in linked.columns]
    rows = []
    group_cols = ["market", "period", "window", "horizon", "tail_prob"]
    for keys, g in linked.groupby(group_cols, dropna=False):
        if len(g) < 10:
            continue
        corr = g[vars_].corr(numeric_only=True)
        for i in corr.index:
            for j in corr.columns:
                if i < j:
                    rows.append(dict(zip(group_cols, keys), var1=i, var2=j, corr=float(corr.loc[i, j]), n_obs=len(g)))
    return pd.DataFrame(rows)


def write_memo(outdir: Path, linked: pd.DataFrame, regs: pd.DataFrame, bins: pd.DataFrame, args) -> None:
    lines = []
    lines.append("# Stage 5: alpha-conditioned DQ vs DR memo")
    lines.append("")
    lines.append("## Inputs")
    lines.append(f"- Rolling metrics: `{args.rolling}`")
    lines.append(f"- Tail alpha estimates: `{args.alpha}`")
    lines.append(f"- Max alpha alignment lag: {args.max_align_days} days")
    lines.append(f"- Min alpha asset match ratio: {args.min_match_ratio}")
    lines.append("")
    lines.append("## Linked sample")
    if linked.empty:
        lines.append("No linked observations were produced. Check date alignment, market/window match, and asset coverage.")
    else:
        summary = linked.groupby(["market", "period", "window", "horizon", "tail_prob"]).size().reset_index(name="n")
        lines.append(summary.to_markdown(index=False))
        lines.append("")
        lines.append("Alpha match ratio summary:")
        lines.append(linked["alpha_match_ratio"].describe().to_frame("alpha_match_ratio").to_markdown())
        lines.append("")
        lines.append("Portfolio alpha summary:")
        cols = ["alpha_median", "alpha_q25", "alpha_share_lt1_point", "alpha_share_gt2_point", "p_alpha_lt_1_mean", "p_alpha_gt_2_mean"]
        cols = [c for c in cols if c in linked.columns]
        lines.append(linked[cols].describe().T.to_markdown())
    lines.append("")
    lines.append("## Regression reading guide")
    lines.append("The key parameters are `z_dq_x_heavy` and `z_dr_x_heavy`. A positive and significant `z_dq_x_heavy`, especially when stronger than the DR interaction, supports the continuous-alpha version of the hypothesis: DQ becomes more informative as tails get heavier.")
    lines.append("")
    lines.append("## Significant interaction coefficients at 10%")
    if regs.empty or "param" not in regs.columns:
        lines.append("No regressions were estimated.")
    else:
        sig = regs[(regs["status"] == "ok") & (regs["param"].isin(["z_dq_x_heavy", "z_dr_x_heavy"])) & (regs["pvalue_hac"] <= 0.10)].copy()
        if sig.empty:
            lines.append("No significant DQ/DR alpha-interaction coefficients at the 10% level.")
        else:
            show = sig[["market", "period", "window", "horizon", "tail_prob", "dependent", "spec", "param", "coef", "t_hac", "pvalue_hac", "r2", "n_obs"]].sort_values(["dependent", "pvalue_hac"])
            lines.append(show.to_markdown(index=False))
    lines.append("")
    lines.append("## Files")
    lines.append("- `01_alpha_linked_rolling_metrics.csv`")
    lines.append("- `02_alpha_interaction_regressions.csv`")
    lines.append("- `03_alpha_bin_summary.csv`")
    lines.append("- `04_alpha_signal_correlations.csv`")
    (outdir / "research_stage5_alpha_interactions_memo.md").write_text("\n".join(lines), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rolling", required=True, help="Stage 2 rolling metrics CSV")
    ap.add_argument("--alpha", required=True, help="Stage 4 alpha estimates CSV/parquet")
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--markets", nargs="*", default=None)
    ap.add_argument("--periods", nargs="*", default=None)
    ap.add_argument("--windows", nargs="*", type=int, default=None)
    ap.add_argument("--horizons", nargs="*", type=int, default=None)
    ap.add_argument("--tail-probs", nargs="*", type=float, default=None)
    ap.add_argument("--max-align-days", type=int, default=45)
    ap.add_argument("--min-match-ratio", type=float, default=0.50)
    ap.add_argument("--min-n", type=int, default=50)
    ap.add_argument("--dependents", nargs="*", default=DEPENDENTS_DEFAULT)
    ap.add_argument("--n-bins", type=int, default=4)
    ap.add_argument("--n-jobs", type=int, default=1, help="Accepted for CLI compatibility. Stage 5 is mostly IO/merge/regression and normally does not benefit from many workers.")
    args = ap.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "00_stage5_config.json").write_text(json.dumps(vars(args), indent=2, ensure_ascii=False), encoding="utf-8")

    rolling = read_table(args.rolling)
    alpha = read_table(args.alpha)

    # Basic filtering.
    if args.markets:
        rolling = rolling[rolling["market"].isin(args.markets)].copy()
        alpha = alpha[alpha["market"].isin(args.markets)].copy()
    if args.periods and "period" in rolling.columns:
        rolling = rolling[rolling["period"].isin(args.periods)].copy()
    if args.windows:
        rolling = rolling[rolling["window"].astype(int).isin(args.windows)].copy()
        alpha = alpha[alpha["window"].astype(int).isin(args.windows)].copy()
    if args.horizons:
        rolling = rolling[rolling["horizon"].astype(int).isin(args.horizons)].copy()
    if args.tail_probs:
        rolling = rolling[rolling["tail_prob"].astype(float).isin(args.tail_probs)].copy()

    linked = link_alpha_to_rolling(
        rolling=rolling,
        alpha=alpha,
        max_align_days=args.max_align_days,
        min_match_ratio=args.min_match_ratio,
    )
    linked.to_csv(outdir / "01_alpha_linked_rolling_metrics.csv", index=False)

    regs = regression_suite(linked, dependents=args.dependents, min_n=args.min_n)
    regs.to_csv(outdir / "02_alpha_interaction_regressions.csv", index=False)

    bins = bin_summary(linked, n_bins=args.n_bins)
    bins.to_csv(outdir / "03_alpha_bin_summary.csv", index=False)

    corrs = correlation_summary(linked)
    corrs.to_csv(outdir / "04_alpha_signal_correlations.csv", index=False)

    write_memo(outdir, linked, regs, bins, args)
    print(f"Done. Outputs written to {outdir}")


if __name__ == "__main__":
    main()
